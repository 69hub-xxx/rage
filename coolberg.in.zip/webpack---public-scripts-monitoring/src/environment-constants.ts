export const SENTRY_DSN = process.env.SENTRY_DSN;
export const ENVIRONMENT = process.env.ENVIRONMENT;
