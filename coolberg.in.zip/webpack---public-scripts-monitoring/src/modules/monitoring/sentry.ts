import * as Sentry from '@sentry/browser';
import { ENVIRONMENT, SENTRY_DSN } from '../../environment-constants';

const SCRIPTS_ID_TAG = 'scripts.id';

const setEventScriptsIdTag = (event: Sentry.ErrorEvent, tag: string): Sentry.ErrorEvent => {
    event.tags = event.tags || {};
    event.tags[SCRIPTS_ID_TAG] = tag;

    return event;
};

const enrichEventWithFullStacktrace = (event: Sentry.ErrorEvent): Sentry.ErrorEvent => {
    event.extra = {
        ...event.extra,
        full_event: JSON.stringify(event, null, 4)
    };

    return event;
};

type ScriptsMetadata = {
    pathRegexp: RegExp;
    id: string;
    ignoredErrors?: string[];
};

const scriptsMetadata: ScriptsMetadata[] = [
    {
        pathRegexp: /https:\/\/[a-zA-Z0-9.-]+\/forms\/main\.js/,
        id: 'inShopForms',
        ignoredErrors: [
            // TypeError: Load failed (unhandled network requests) (CO-5481) Added date: 2024-10-08
            'TypeError: Load failed'
        ]
    },
    {
        pathRegexp: /https:\/\/[a-zA-Z0-9.-]+\/forms\/landingPage\.js/,
        id: 'landingPage'
    }
];

export const initializeMonitoring = (): void => {
    Sentry.init({
        dsn: SENTRY_DSN,
        environment: ENVIRONMENT,
        enabled: true,
        integrations: [
            Sentry.browserApiErrorsIntegration({
                setTimeout: true,
                setInterval: true,
                requestAnimationFrame: true,
                XMLHttpRequest: true,
                // This option wraps native addEventListener/removeEventListener functions
                // Due to race conditions of sentry plugin and some other plugins (e.g. woocommerce "Astra" addon) initialization
                // some event listeners from other plugins might get registered multiple times which can cause some unexpected behavior. (CO-5506)
                // ***
                // TODO:
                // Possible solution to catch exceptions from event listeners:
                // We can wrap addEventListener/removeEventListener by catching event listeners registered to our plugins DOM elements only
                // using Sentry custom integration
                eventTarget: false
            })
        ],
        tracesSampleRate: 0,
        allowUrls: scriptsMetadata.map(({ pathRegexp }) => pathRegexp),
        beforeSend(event) {
            const stacktrace = event?.exception?.values?.length && event.exception.values[0]?.stacktrace;
            const errorMessage = (event?.exception?.values?.length && event.exception.values[0]?.value) || '';

            if (!stacktrace || !stacktrace?.frames?.length) {
                return null;
            }

            scriptsMetadata.forEach(({ pathRegexp, id, ignoredErrors }) => {
                const hasScriptsPathInStacktrace = stacktrace.frames.some((frame) => pathRegexp.test(frame.filename));
                const isErrorIgnored = ignoredErrors?.some((ignoredErrorMessage) => errorMessage.includes(ignoredErrorMessage));

                if (hasScriptsPathInStacktrace && !isErrorIgnored) {
                    event = setEventScriptsIdTag(event, id);
                }
            });

            if (event.tags?.[SCRIPTS_ID_TAG]) {
                event = enrichEventWithFullStacktrace(event);

                return event;
            }

            return null;
        }
    });
};
