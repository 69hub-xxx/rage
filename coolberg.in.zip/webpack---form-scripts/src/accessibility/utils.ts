export function getFirst<T extends HTMLElement>(elementList: T[]): T | undefined {
    return elementList[0];
}

export function getLast<T extends HTMLElement>(elementList: T[]): T | undefined {
    return elementList[elementList.length - 1];
}
