export const FORMS_API_HOST = process.env.FORMS_API_HOST;
export const MONITORING_HOST = process.env.MONITORING_HOST;
export const ENVIRONMENT = process.env.ENVIRONMENT;
