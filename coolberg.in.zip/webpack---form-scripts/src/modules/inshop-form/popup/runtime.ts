import { getContext } from '../../../context';
import { evaluateFormTargeting, isDeviceSupported } from './targeting';
import { monitorActivity, onActivityChange } from './activity-monitoring';
import { createPopupForm } from './popup-form';
import { initiateFormTeasers, showAvailableFormsTeasers } from './form-teaser';
import { PopupForm } from './types';
import { InshopFormData } from '../types';
import { monitorCustomTriggerOnlyForms } from './custom-trigger';

function tryToShowFormsAndTeasers(forms: PopupForm[]): void {
    const context = getContext();
    if (!context.forms.checkIfWindowIsClear()) {
        return;
    }

    showAvailableFormsTeasers();
    forms
        .filter((form) => evaluateFormTargeting(form.data))
        .forEach((form) => {
            if (form.data.teaser?.showBeforeOpen) {
                return;
            }

            form.show();
        });
}

export const initiate = async (forms: InshopFormData[]): Promise<void> => {
    const popupForms: PopupForm[] = forms.map((data) => createPopupForm(data));

    const { formsWithCustomTriggerOnly, otherForms } = popupForms.reduce(
        (result, form) => {
            if (form.data.targeting?.display?.customTrigger === 'only') {
                result.formsWithCustomTriggerOnly = [...result.formsWithCustomTriggerOnly, form];
                return result;
            }

            if (!isDeviceSupported(form.data.targeting?.device)) {
                return result;
            }

            result.otherForms = [...result.otherForms, form];

            return result;
        },
        {
            formsWithCustomTriggerOnly: [],
            otherForms: []
        }
    );

    if (formsWithCustomTriggerOnly.length) {
        monitorCustomTriggerOnlyForms(formsWithCustomTriggerOnly);
    }

    if (!otherForms.length) {
        return;
    }

    monitorActivity();

    initiateFormTeasers(otherForms);

    onActivityChange(() => tryToShowFormsAndTeasers(otherForms));

    setInterval(() => {
        tryToShowFormsAndTeasers(otherForms);
    }, 1000);
};
