! function(e) {
    "use strict";
    const n = {
            TRACKING_ACCEPTED: "trackingConsentAccepted",
            TRACKING_DECLINED: "trackingConsentDeclined",
            MARKETING_ACCEPTED: "firstPartyMarketingConsentAccepted",
            SALE_OF_DATA_ACCEPTED: "thirdPartyMarketingConsentAccepted",
            ANALYTICS_ACCEPTED: "analyticsConsentAccepted",
            PREFERENCES_ACCEPTED: "preferencesConsentAccepted",
            MARKETING_DECLINED: "firstPartyMarketingConsentDeclined",
            SALE_OF_DATA_DECLINED: "thirdPartyMarketingConsentDeclined",
            ANALYTICS_DECLINED: "analyticsConsentDeclined",
            PREFERENCES_DECLINED: "preferencesConsentDeclined",
            CONSENT_COLLECTED: "visitorConsentCollected",
            CONSENT_TRACKING_API_LOADED: "consentTrackingApiLoaded"
        },
        t = "2.1",
        o = "3",
        r = {
            ACCEPTED: "yes",
            DECLINED: "no",
            NO_INTERACTION: "no_interaction",
            NO_VALUE: ""
        },
        i = {
            NO_VALUE: "",
            ACCEPTED: "1",
            DECLINED: "0"
        },
        c = {
            PREFERENCES: "p",
            ANALYTICS: "a",
            MARKETING: "m",
            SALE_OF_DATA: "t"
        },
        a = {
            MARKETING: "m",
            ANALYTICS: "a",
            PREFERENCES: "p",
            SALE_OF_DATA: "s"
        },
        s = {
            MARKETING: "marketing",
            ANALYTICS: "analytics",
            PREFERENCES: "preferences",
            SALE_OF_DATA: "sale_of_data",
            EMAIL: "email"
        },
        u = {
            HEADLESS_STOREFRONT: "headlessStorefront",
            ROOT_DOMAIN: "rootDomain",
            CHECKOUT_ROOT_DOMAIN: "checkoutRootDomain",
            STOREFRONT_ROOT_DOMAIN: "storefrontRootDomain",
            STOREFRONT_ACCESS_TOKEN: "storefrontAccessToken",
            IS_EXTENSION_TOKEN: "isExtensionToken",
            METAFIELDS: "metafields"
        };

    function l(e, n) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var o = Object.getOwnPropertySymbols(e);
            n && (o = o.filter((function(n) {
                return Object.getOwnPropertyDescriptor(e, n).enumerable
            }))), t.push.apply(t, o)
        }
        return t
    }

    function E(e) {
        for (var n = 1; n < arguments.length; n++) {
            var t = null != arguments[n] ? arguments[n] : {};
            n % 2 ? l(Object(t), !0).forEach((function(n) {
                d(e, n, t[n])
            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : l(Object(t)).forEach((function(n) {
                Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n))
            }))
        }
        return e
    }

    function d(e, n, t) {
        return n in e ? Object.defineProperty(e, n, {
            value: t,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = t, e
    }
    class f {}
    f.warn = e => {
        console.warn(e)
    }, f.error = e => {
        console.error(e)
    }, f.info = e => {
        console.info(e)
    }, f.debug = e => {
        console.debug(e)
    }, f.trace = e => {
        console.trace(e)
    };
    const A = f;

    function C(e) {
        let n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        const t = document.cookie ? document.cookie.split("; ") : [];
        for (let n = 0; n < t.length; n++) {
            const [o, r] = t[n].split("=");
            if (e === decodeURIComponent(o)) {
                return decodeURIComponent(r)
            }
        }
        if (n && "_tracking_consent" === e && !window.localStorage.getItem("tracking_consent_fetched")) return console.debug("_tracking_consent missing"),
            function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "/";
                const n = new XMLHttpRequest;
                n.open("HEAD", e, !1), n.withCredentials = !0, n.send()
            }(), window.localStorage.setItem("tracking_consent_fetched", "true"), C(e, !1)
    }

    function p(e) {
        return e === encodeURIComponent(decodeURIComponent(e))
    }

    function T(e, n, t, o) {
        if (!p(o)) throw new TypeError("Cookie value is not correctly URI encoded.");
        if (!p(e)) throw new TypeError("Cookie name is not correctly URI encoded.");
        let r = "".concat(e, "=").concat(o);
        r += "; path=/", n && (r += "; domain=".concat(n)), r += "; expires=".concat(new Date((new Date).getTime() + t).toUTCString()), document.cookie = r
    }
    const g = "_tracking_consent",
        _ = 31536e6;

    function N() {
        const e = C(g);
        if (void 0 !== e) return function(e) {
            const n = e.slice(0, 1);
            if ("{" == n) return function(e) {
                var n;
                let o;
                try {
                    o = JSON.parse(e)
                } catch (e) {
                    return
                }
                if (o.v !== t) return;
                if (null === (n = o.con) || void 0 === n || !n.CMP) return;
                return o
            }(e);
            if ("3" == n) return function(e) {
                const n = e.slice(1).split("_"),
                    [t, r, s, u, l] = n;
                let E, d;
                try {
                    E = n[5] ? JSON.parse(n.slice(5).join("_")) : void 0
                } catch (e) {}
                if (l) {
                    const e = Array.from(atob(l)).map((e => e.charCodeAt(0).toString(16).padStart(2, "0"))).join("");
                    d = [8, 13, 18, 23].reduce(((e, n) => e.slice(0, n) + "-" + e.slice(n)), e)
                }

                function f(e) {
                    const n = t.split(".")[0];
                    return n.includes(e.toLowerCase()) ? i.DECLINED : n.includes(e.toUpperCase()) ? i.ACCEPTED : i.NO_VALUE
                }

                function A(e) {
                    return t.includes(e.replace("t", "s").toUpperCase())
                }
                return {
                    v: o,
                    con: {
                        CMP: {
                            [a.ANALYTICS]: f(a.ANALYTICS),
                            [a.PREFERENCES]: f(a.PREFERENCES),
                            [a.MARKETING]: f(a.MARKETING),
                            [a.SALE_OF_DATA]: f(a.SALE_OF_DATA)
                        }
                    },
                    region: r || "",
                    cus: E,
                    purposes: {
                        [c.ANALYTICS]: A(c.ANALYTICS),
                        [c.PREFERENCES]: A(c.PREFERENCES),
                        [c.MARKETING]: A(c.MARKETING),
                        [c.SALE_OF_DATA]: A(c.SALE_OF_DATA)
                    },
                    sale_of_data_region: "t" == u,
                    display_banner: "t" == s,
                    consent_id: d
                }
            }(e);
            return
        }(e)
    }

    function h() {
        try {
            let e = N();
            if (!e) return;
            return e
        } catch (e) {
            return
        }
    }

    function S() {
        return {
            m: w(a.MARKETING),
            a: w(a.ANALYTICS),
            p: w(a.PREFERENCES),
            s: w(a.SALE_OF_DATA)
        }
    }

    function m() {
        return S()[a.SALE_OF_DATA]
    }

    function D() {
        let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
        return null === e && (e = h()), void 0 === e
    }

    function y(e) {
        switch (e) {
            case i.ACCEPTED:
                return r.ACCEPTED;
            case i.DECLINED:
                return r.DECLINED;
            default:
                return r.NO_VALUE
        }
    }

    function I(e) {
        switch (e) {
            case a.ANALYTICS:
                return s.ANALYTICS;
            case a.MARKETING:
                return s.MARKETING;
            case a.PREFERENCES:
                return s.PREFERENCES;
            case a.SALE_OF_DATA:
                return s.SALE_OF_DATA
        }
    }

    function w(e) {
        const n = h();
        if (!n) return i.NO_VALUE;
        const t = n.con.CMP;
        return t ? t[e] : i.NO_VALUE
    }

    function R() {
        const e = h();
        return D(e) ? "" : e.region || ""
    }

    function O(e) {
        const n = N();
        if (!n || !n.purposes) return !0;
        const t = n.purposes[e];
        return "boolean" != typeof t || t
    }

    function P() {
        return O(c.PREFERENCES)
    }

    function L() {
        return O(c.ANALYTICS)
    }

    function v() {
        return O(c.MARKETING)
    }

    function k() {
        return O(c.SALE_OF_DATA)
    }

    function b() {
        const e = N();
        return !!e && ("boolean" == typeof e.display_banner && e.display_banner)
    }

    function M() {
        const e = N();
        return e && e.sale_of_data_region || !1
    }
    class F {
        constructor() {
            let e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.useInstrumentation = void 0, F.instance) return F.instance;
            F.instance = this, this.useInstrumentation = e
        }
        instrumentationEnabled() {
            return this.useInstrumentation
        }
        setUseInstrumentation(e) {
            this.useInstrumentation = e
        }
        produce(e, n) {
            if (this.instrumentationEnabled() && L()) try {
                const t = {
                        schema_id: "customer_privacy_api_events/2.0",
                        payload: {
                            shop_domain: window.location.host,
                            method_name: e,
                            call_details: n || null
                        }
                    },
                    o = {
                        accept: "*/*",
                        "accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
                        "content-type": "application/json; charset=utf-8",
                        "x-monorail-edge-event-created-at-ms": String(Date.now()),
                        "x-monorail-edge-event-sent-at-ms": String(Date.now())
                    };
                if (!window.location.host.endsWith("spin.dev")) return fetch("https://monorail-edge.shopifysvc.com/v1/produce", {
                    headers: o,
                    body: JSON.stringify(t),
                    method: "POST",
                    mode: "cors",
                    credentials: "omit"
                });
                console.log("Monorail event from consent API:", o, t)
            } catch (e) {}
        }
    }

    function K(e) {
        void 0 !== e.granular_consent && function(e) {
            const t = e[c.MARKETING],
                o = e[c.SALE_OF_DATA],
                r = e[c.ANALYTICS],
                i = e[c.PREFERENCES];
            !0 === t ? G(n.MARKETING_ACCEPTED) : !1 === t && G(n.MARKETING_DECLINED);
            !0 === o ? G(n.SALE_OF_DATA_ACCEPTED) : !1 === o && G(n.SALE_OF_DATA_DECLINED);
            !0 === r ? G(n.ANALYTICS_ACCEPTED) : !1 === r && G(n.ANALYTICS_DECLINED);
            !0 === i ? G(n.PREFERENCES_ACCEPTED) : !1 === i && G(n.PREFERENCES_DECLINED);
            const a = function(e) {
                const n = {
                    marketingAllowed: e[c.MARKETING],
                    saleOfDataAllowed: e[c.SALE_OF_DATA],
                    analyticsAllowed: e[c.ANALYTICS],
                    preferencesAllowed: e[c.PREFERENCES],
                    firstPartyMarketingAllowed: e[c.MARKETING],
                    thirdPartyMarketingAllowed: e[c.SALE_OF_DATA]
                };
                return n
            }(e);
            G(n.CONSENT_COLLECTED, a);
            const s = [r, i, t, o];
            s.every((e => !0 === e)) && G(n.TRACKING_ACCEPTED);
            s.every((e => !1 === e)) && G(n.TRACKING_DECLINED)
        }({
            [c.PREFERENCES]: P(),
            [c.ANALYTICS]: L(),
            [c.MARKETING]: v(),
            [c.SALE_OF_DATA]: k()
        })
    }

    function G(e, n) {
        document.dispatchEvent(new CustomEvent(e, {
            detail: n || {}
        }))
    }

    function j(e, n) {
        if (null === e) return "null";
        if (Array.isArray(e)) {
            const n = e.map((e => j(e, !0))).join(",");
            return "[".concat(n, "]")
        }
        if ("object" == typeof e) {
            let t = [];
            for (const n in e) e.hasOwnProperty(n) && void 0 !== e[n] && t.push("".concat(n, ":").concat(j(e[n], !0)));
            const o = t.join(",");
            return n ? "{".concat(o, "}") : o
        }
        return "string" == typeof e ? '"'.concat(e, '"') : "".concat(e)
    }
    F.instance = void 0;
    const U = "_landing_page",
        Y = "_orig_referrer";

    function B(e) {
        const n = e.granular_consent,
            t = j(E(E({
                visitorConsent: E({
                    marketing: n.marketing,
                    analytics: n.analytics,
                    preferences: n.preferences,
                    saleOfData: n.sale_of_data
                }, n.metafields && {
                    metafields: n.metafields
                })
            }, n.email && {
                visitorEmail: n.email
            }), {}, {
                origReferrer: e.referrer,
                landingPage: e.landing_page
            }));
        return {
            query: "query { consentManagement { cookies(".concat(t, ") { trackingConsentCookie cookieDomain landingPageCookie origReferrerCookie } } }"),
            variables: {}
        }
    }

    function x(e, n) {
        const t = e.granular_consent,
            o = t.storefrontAccessToken || function() {
                const e = document.documentElement.querySelector("#shopify-features"),
                    n = "Could not find liquid access token";
                if (!e) return void A.warn(n);
                const t = JSON.parse(e.textContent || "").accessToken;
                if (!t) return void A.warn(n);
                return t
            }(),
            r = t.checkoutRootDomain || window.location.host,
            i = t.isExtensionToken ? "Shopify-Storefront-Extension-Token" : "x-shopify-storefront-access-token",
            c = {
                headers: {
                    "content-type": "application/json",
                    [i]: o
                },
                body: JSON.stringify(B(e)),
                method: "POST"
            };
        return fetch("https://".concat(r, "/api/unstable/graphql.json"), c).then((e => {
            if (e.ok) return e.json();
            throw new Error("Server error")
        })).then((o => {
            const r = 31536e6,
                i = 12096e5,
                c = o.data.consentManagement.cookies.cookieDomain,
                a = c || t.checkoutRootDomain || window.location.hostname,
                s = t.storefrontRootDomain || c || window.location.hostname,
                u = o.data.consentManagement.cookies.trackingConsentCookie,
                l = o.data.consentManagement.cookies.landingPageCookie,
                E = o.data.consentManagement.cookies.origReferrerCookie;
            return T(g, a, r, u), l && E && (T(U, a, i, l), T(Y, a, i, E)), s !== a && (T(g, s, r, u), l && E && (T(U, s, i, l), T(Y, s, i, E))), K(e), void 0 !== n && n(null, o), o
        })).catch((e => {
            const t = "Error while setting storefront API consent: " + e.message;
            if (void 0 === n) throw {
                error: t
            };
            n({
                error: t
            })
        }))
    }

    function V(e, n) {
        if (function(e) {
                if ("boolean" != typeof e && "object" != typeof e) throw TypeError("setTrackingConsent must be called with a boolean or object consent value");
                if ("object" == typeof e) {
                    const n = Object.keys(e);
                    if (0 === n.length) throw TypeError("The submitted consent object is empty.");
                    const t = [s.MARKETING, s.ANALYTICS, s.PREFERENCES, s.SALE_OF_DATA, s.EMAIL, u.ROOT_DOMAIN, u.CHECKOUT_ROOT_DOMAIN, u.STOREFRONT_ROOT_DOMAIN, u.STOREFRONT_ACCESS_TOKEN, u.HEADLESS_STOREFRONT, u.IS_EXTENSION_TOKEN, u.METAFIELDS];
                    for (const e of n)
                        if (!t.includes(e)) throw TypeError("The submitted consent object should only contain the following keys: ".concat(t.join(", "), ". Extraneous key: ").concat(e, "."))
                }
            }(e), void 0 !== n && "function" != typeof n) throw TypeError("setTrackingConsent must be called with a callback function if the callback argument is provided");
        let t;
        if (!0 === e || !1 === e) {
            A.warn("Binary consent is deprecated. Please update to granular consent (shopify.dev/docs/api/consent-tracking)");
            t = {
                analytics: e,
                preferences: e,
                marketing: e
            }
        } else t = e;
        const o = function(e) {
                if (!e) return null;
                return W() ? document.referrer : ""
            }(t.analytics),
            r = function(e) {
                if (!e) return null;
                return W() ? window.location.pathname + window.location.search : "/"
            }(t.analytics);
        return x(E(E({
            granular_consent: t
        }, null !== o && {
            referrer: o
        }), null !== r && {
            landing_page: r
        }), n)
    }

    function H(e, n) {
        if (A.warn("This method is deprecated. Please read shopify.dev/docs/api/customer-privacy for the latest information."), "boolean" != typeof e) throw TypeError("setCCPAConsent must be called with a boolean consent value");
        if ("function" != typeof n) throw TypeError("setCCPAConsent must be called with a callback function");
        return x({
            granular_consent: {
                sale_of_data: e
            }
        }, n)
    }

    function q() {
        if ((new F).produce("getTrackingConsent"), D()) return r.NO_VALUE;
        const e = S();
        return e[a.MARKETING] === i.ACCEPTED && e[a.ANALYTICS] === i.ACCEPTED ? r.ACCEPTED : e[a.MARKETING] === i.DECLINED || e[a.ANALYTICS] === i.DECLINED ? r.DECLINED : r.NO_INTERACTION
    }

    function J() {
        (new F).produce("getRegulation"), A.warn("getRegulation is deprecated and will be removed.");
        const e = R();
        return "" === e ? "" : ["AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IS", "IE", "IT", "LV", "LI", "LT", "LU", "MT", "NL", "NO", "PL", "PT", "RO", "SI", "SK", "ES", "SE", "GB"].includes(e.slice(0, 2)) ? "GDPR" : "US" === e.slice(0, 2) && ["CA", "VA"].includes(e.slice(2, 4)) ? "CCPA" : ""
    }

    function X() {
        return (new F).produce("getShopPrefs"), A.warn("getShopPrefs is deprecated and will be removed."), {
            limit: []
        }
    }

    function $() {
        return R()
    }

    function W() {
        if ("" === document.referrer) return !0;
        const e = document.createElement("a");
        return e.href = document.referrer, window.location.hostname != e.hostname
    }

    function Z() {
        return (new F).produce("isRegulationEnforced"), A.warn("isRegulationEnforced is deprecated and will be removed."), !0
    }

    function z() {
        return !!D() || v() && L()
    }

    function Q() {
        return M() ? "string" == typeof navigator.globalPrivacyControl ? "1" !== navigator.globalPrivacyControl : "boolean" == typeof navigator.globalPrivacyControl ? !navigator.globalPrivacyControl : null : null
    }

    function ee() {
        return A.warn("userDataCanBeSold is deprecated and will be replaced with saleOfDataAllowed."), k()
    }

    function ne() {
        return b() && q() === r.NO_INTERACTION
    }

    function te() {
        return !1 === Q() ? r.DECLINED : (e = m(), D() ? r.NO_VALUE : e === i.NO_VALUE ? r.NO_INTERACTION : y(e));
        var e
    }

    function oe() {
        return (new F).produce("shouldShowCCPABanner"), A.warn("shouldShowCCPABanner is deprecated and will be removed."), M() && te() === r.NO_INTERACTION
    }

    function re() {
        return !0
    }

    function ie(e) {
        return function(e) {
            const n = h();
            if (D(n) || !n.cus) return;
            const t = n.cus[encodeURIComponent(e)];
            return t ? decodeURIComponent(t) : t
        }(e)
    }
    const ce = "95ba910bcec4542ef2a0b64cd7ca666c";

    function ae(e, n, t) {
        try {
            var o;
            ! function(e) {
                const n = new XMLHttpRequest;
                n.open("POST", "https://notify.bugsnag.com/", !0), n.setRequestHeader("Content-Type", "application/json"), n.setRequestHeader("Bugsnag-Api-Key", ce), n.setRequestHeader("Bugsnag-Payload-Version", "5");
                const t = function(e) {
                    const n = function(e) {
                            return e.stackTrace || e.stack || e.description || e.name
                        }(e.error),
                        [t, o] = (n || "unknown error").split("\n")[0].split(":");
                    return JSON.stringify({
                        payloadVersion: 5,
                        notifier: {
                            name: "ConsentTrackingAPI",
                            version: "latest",
                            url: "-"
                        },
                        events: [{
                            exceptions: [{
                                errorClass: (t || "").trim(),
                                message: (o || "").trim(),
                                stacktrace: [{
                                    file: "consent-tracking-api.js",
                                    lineNumber: "1",
                                    method: n
                                }],
                                type: "browserjs"
                            }],
                            context: e.context || "general",
                            app: {
                                id: "ConsentTrackingAPI",
                                version: "latest"
                            },
                            metaData: {
                                request: {
                                    shopId: e.shopId,
                                    shopUrl: window.location.href
                                },
                                device: {
                                    userAgent: window.navigator.userAgent
                                },
                                "Additional Notes": e.notes
                            },
                            unhandled: !1
                        }]
                    })
                }(e);
                n.send(t)
            }({
                error: e,
                context: n,
                shopId: ue() || (null === (o = window.Shopify) || void 0 === o ? void 0 : o.shop),
                notes: t
            })
        } catch (e) {}
    }

    function se(e) {
        return function() {
            try {
                return e(...arguments)
            } catch (e) {
                throw e instanceof TypeError || ae(e), e
            }
        }
    }

    function ue() {
        try {
            const e = document.getElementById("shopify-features").textContent;
            return JSON.parse(e).shopId
        } catch (e) {
            return null
        }
    }

    function le() {
        return v()
    }

    function Ee() {
        return k()
    }

    function de() {
        const e = {},
            n = S();
        for (const t of Object.keys(n)) e[I(t)] = y(n[t]);
        return e
    }

    function fe(e, n) {
        const o = new F;
        return o.produce("setTrackingConsent"), "object" == typeof e && e.headlessStorefront && !e.storefrontAccessToken ? (A.warn("Headless consent has been updated. Please read shopify.dev/docs/api/customer-privacy to integrate."), o.produce("setTrackingConsent-Headless"), function(e, n) {
            function o(e) {
                let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i.NO_VALUE;
                return !0 === e ? i.ACCEPTED : !1 === e ? i.DECLINED : n
            }
            const r = {
                    [a.ANALYTICS]: o(e[s.ANALYTICS], i.DECLINED),
                    [a.MARKETING]: o(e[s.MARKETING], i.DECLINED),
                    [a.PREFERENCES]: o(e[s.PREFERENCES], i.DECLINED),
                    [a.SALE_OF_DATA]: o(e[s.SALE_OF_DATA])
                },
                c = {
                    v: t,
                    reg: "",
                    con: {
                        CMP: r
                    }
                },
                u = encodeURIComponent(JSON.stringify(c));
            return T(g, e.rootDomain, _, u), n(null), new Promise(((e, n) => {}))
        }(e, n || (() => {}))) : V(e, n)
    }
    const Ae = e => {
        let {
            useBugsnagReporting: n,
            useInstrumentation: t
        } = e;
        m() != i.DECLINED && !1 === Q() && H(!1, (() => !1));
        const o = {
            getTrackingConsent: q,
            setTrackingConsent: fe,
            userCanBeTracked: z,
            getRegulation: J,
            isRegulationEnforced: Z,
            getShopPrefs: X,
            shouldShowGDPRBanner: ne,
            userDataCanBeSold: ee,
            setCCPAConsent: H,
            getCCPAConsent: te,
            shouldShowCCPABanner: oe,
            doesMerchantSupportGranularConsent: re,
            analyticsProcessingAllowed: L,
            preferencesProcessingAllowed: P,
            marketingAllowed: le,
            firstPartyMarketingAllowed: le,
            saleOfDataAllowed: Ee,
            thirdPartyMarketingAllowed: Ee,
            currentVisitorConsent: de,
            shouldShowBanner: b,
            saleOfDataRegion: M,
            getRegion: $,
            getTrackingConsentMetafield: ie,
            unstable: {
                analyticsProcessingAllowed: L,
                preferencesProcessingAllowed: P,
                marketingAllowed: le,
                saleOfDataAllowed: Ee,
                currentVisitorConsent: de,
                shouldShowBanner: b,
                saleOfDataRegion: M
            },
            __metadata__: {
                name: "@shopify/consent-tracking-api",
                version: "v0.1",
                description: "Shopify Consent Tracking API"
            }
        };
        if (new F(t), !n) return o;
        const r = ["unstable", "__metadata__"];
        for (const e in o) o.hasOwnProperty(e) && (o[e] = r.includes(e) ? o[e] : se(o[e]));
        return o
    };

    function Ce() {
        return Ae(arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
            useBugsnagReporting: !1,
            useInstrumentation: !1
        })
    }

    function pe() {
        var e, t;
        const o = Ce({
            useBugsnagReporting: !0,
            useInstrumentation: !0
        });
        if (window.Shopify.trackingConsent || window.Shopify.customerPrivacy) {
            const n = null === (e = window.Shopify.customerPrivacy.__metadata__) || void 0 === e ? void 0 : e.version,
                r = null === (t = o.__metadata__) || void 0 === t ? void 0 : t.version,
                i = `Multiple versions of Shopify.trackingConsent or Shopify.customerPrivacy loaded -  Version '${n}' is already loaded but replacing with version '${r}'.\n\nThis could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.`,
                c = "Shopify.trackingConsent or Shopify.customerPrivacy already exists.\n\nLoading multiple versions could result in unexpected behavior. See documentation https://shopify.dev/docs/api/customer-privacy for more information.";
            console.warn(n && r ? i : c)
        }
        window.Shopify.customerPrivacy = window.Shopify.trackingConsent = o, G(n.CONSENT_TRACKING_API_LOADED)
    }
    window.Shopify = window.Shopify ? window.Shopify : {}, pe(), e.default = Ce, e.setGlobalObject = pe, Object.defineProperty(e, "__esModule", {
        value: !0
    })
}({});
//# sourceMappingURL=consent-tracking-api.js.map