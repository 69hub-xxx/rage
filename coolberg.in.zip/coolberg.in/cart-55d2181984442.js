{
    "token": "6e590933d19a2a1f46e80957ec97a6ca",
    "note": null,
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "INR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": []
}