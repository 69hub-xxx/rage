! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "8da61b25-2b92-489b-9221-fd85c0152e19", t._sentryDebugIdIdentifier = "sentry-dbid-8da61b25-2b92-489b-9221-fd85c0152e19")
    } catch (t) {}
}(),
function() {
    "use strict";
    const t = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
        e = "8.19.0",
        n = globalThis;

    function r(t, r, s) {
        const o = s || n,
            i = o.__SENTRY__ = o.__SENTRY__ || {},
            a = i[e] = i[e] || {};
        return a[t] || (a[t] = r())
    }
    const s = ["debug", "info", "warn", "error", "log", "assert", "trace"],
        o = {};

    function i(t) {
        if (!("console" in n)) return t();
        const e = n.console,
            r = {},
            s = Object.keys(o);
        s.forEach((t => {
            const n = o[t];
            r[t] = e[t], e[t] = n
        }));
        try {
            return t()
        } finally {
            s.forEach((t => {
                e[t] = r[t]
            }))
        }
    }
    const a = function() {
            let e = !1;
            const r = {
                enable: () => {
                    e = !0
                },
                disable: () => {
                    e = !1
                },
                isEnabled: () => e
            };
            return t ? s.forEach((t => {
                r[t] = (...r) => {
                    e && i((() => {
                        n.console[t](`Sentry Logger [${t}]:`, ...r)
                    }))
                }
            })) : s.forEach((t => {
                r[t] = () => {}
            })), r
        }(),
        c = Object.prototype.toString;

    function u(t) {
        switch (c.call(t)) {
            case "[object Error]":
            case "[object Exception]":
            case "[object DOMException]":
                return !0;
            default:
                return v(t, Error)
        }
    }

    function l(t, e) {
        return c.call(t) === `[object ${e}]`
    }

    function p(t) {
        return l(t, "ErrorEvent")
    }

    function d(t) {
        return l(t, "DOMError")
    }

    function f(t) {
        return l(t, "String")
    }

    function h(t) {
        return "object" == typeof t && null !== t && "__sentry_template_string__" in t && "__sentry_template_values__" in t
    }

    function m(t) {
        return null === t || h(t) || "object" != typeof t && "function" != typeof t
    }

    function _(t) {
        return l(t, "Object")
    }

    function g(t) {
        return "undefined" != typeof Event && v(t, Event)
    }

    function y(t) {
        return Boolean(t && t.then && "function" == typeof t.then)
    }

    function v(t, e) {
        try {
            return t instanceof e
        } catch (t) {
            return !1
        }
    }

    function b(t) {
        return !("object" != typeof t || null === t || !t.__isVue && !t._isVue)
    }
    const E = n,
        S = 80;

    function x(t, e = {}) {
        if (!t) return "<unknown>";
        try {
            let n = t;
            const r = 5,
                s = [];
            let o = 0,
                i = 0;
            const a = " > ",
                c = a.length;
            let u;
            const l = Array.isArray(e) ? e : e.keyAttrs,
                p = !Array.isArray(e) && e.maxStringLength || S;
            for (; n && o++ < r && (u = w(n, l), !("html" === u || o > 1 && i + s.length * c + u.length >= p));) s.push(u), i += u.length, n = n.parentNode;
            return s.reverse().join(a)
        } catch (t) {
            return "<unknown>"
        }
    }

    function w(t, e) {
        const n = t,
            r = [];
        if (!n || !n.tagName) return "";
        if (E.HTMLElement && n instanceof HTMLElement && n.dataset) {
            if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
            if (n.dataset.sentryElement) return n.dataset.sentryElement
        }
        r.push(n.tagName.toLowerCase());
        const s = e && e.length ? e.filter((t => n.getAttribute(t))).map((t => [t, n.getAttribute(t)])) : null;
        if (s && s.length) s.forEach((t => {
            r.push(`[${t[0]}="${t[1]}"]`)
        }));
        else {
            n.id && r.push(`#${n.id}`);
            const t = n.className;
            if (t && f(t)) {
                const e = t.split(/\s+/);
                for (const t of e) r.push(`.${t}`)
            }
        }
        const o = ["aria-label", "type", "name", "title", "alt"];
        for (const t of o) {
            const e = n.getAttribute(t);
            e && r.push(`[${t}="${e}"]`)
        }
        return r.join("")
    }

    function k(t, e = 0) {
        return "string" != typeof t || 0 === e || t.length <= e ? t : `${t.slice(0,e)}...`
    }

    function O(t, e) {
        if (!Array.isArray(t)) return "";
        const n = [];
        for (let e = 0; e < t.length; e++) {
            const r = t[e];
            try {
                b(r) ? n.push("[VueViewModel]") : n.push(String(r))
            } catch (t) {
                n.push("[value cannot be serialized]")
            }
        }
        return n.join(e)
    }

    function T(t, e = [], n = !1) {
        return e.some((e => function(t, e, n = !1) {
            return !!f(t) && (l(e, "RegExp") ? e.test(t) : !!f(e) && (n ? t === e : t.includes(e)))
        }(t, e, n)))
    }

    function $(t, e, n) {
        if (!(e in t)) return;
        const r = t[e],
            s = n(r);
        "function" == typeof s && N(s, r), t[e] = s
    }

    function D(e, n, r) {
        try {
            Object.defineProperty(e, n, {
                value: r,
                writable: !0,
                configurable: !0
            })
        } catch (r) {
            t && a.log(`Failed to add non-enumerable property "${n}" to object`, e)
        }
    }

    function N(t, e) {
        try {
            const n = e.prototype || {};
            t.prototype = e.prototype = n, D(t, "__sentry_original__", e)
        } catch (t) {}
    }

    function I(t) {
        return t.__sentry_original__
    }

    function P(t) {
        if (u(t)) return {
            message: t.message,
            name: t.name,
            stack: t.stack,
            ...R(t)
        };
        if (g(t)) {
            const e = {
                type: t.type,
                target: j(t.target),
                currentTarget: j(t.currentTarget),
                ...R(t)
            };
            return "undefined" != typeof CustomEvent && v(t, CustomEvent) && (e.detail = t.detail), e
        }
        return t
    }

    function j(t) {
        try {
            return "undefined" != typeof Element && v(t, Element) ? x(t) : Object.prototype.toString.call(t)
        } catch (t) {
            return "<unknown>"
        }
    }

    function R(t) {
        if ("object" == typeof t && null !== t) {
            const e = {};
            for (const n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
            return e
        }
        return {}
    }

    function C(t) {
        return A(t, new Map)
    }

    function A(t, e) {
        if (function(t) {
                if (!_(t)) return !1;
                try {
                    const e = Object.getPrototypeOf(t).constructor.name;
                    return !e || "Object" === e
                } catch (t) {
                    return !0
                }
            }(t)) {
            const n = e.get(t);
            if (void 0 !== n) return n;
            const r = {};
            e.set(t, r);
            for (const n of Object.keys(t)) void 0 !== t[n] && (r[n] = A(t[n], e));
            return r
        }
        if (Array.isArray(t)) {
            const n = e.get(t);
            if (void 0 !== n) return n;
            const r = [];
            return e.set(t, r), t.forEach((t => {
                r.push(A(t, e))
            })), r
        }
        return t
    }

    function L() {
        const t = n,
            e = t.crypto || t.msCrypto;
        let r = () => 16 * Math.random();
        try {
            if (e && e.randomUUID) return e.randomUUID().replace(/-/g, "");
            e && e.getRandomValues && (r = () => {
                const t = new Uint8Array(1);
                return e.getRandomValues(t), t[0]
            })
        } catch (t) {}
        return ([1e7] + 1e3 + 4e3 + 8e3 + 1e11).replace(/[018]/g, (t => (t ^ (15 & r()) >> t / 4).toString(16)))
    }

    function M(t) {
        return t.exception && t.exception.values ? t.exception.values[0] : void 0
    }

    function U(t) {
        const {
            message: e,
            event_id: n
        } = t;
        if (e) return e;
        const r = M(t);
        return r ? r.type && r.value ? `${r.type}: ${r.value}` : r.type || r.value || n || "<unknown>" : n || "<unknown>"
    }

    function q(t, e, n) {
        const r = t.exception = t.exception || {},
            s = r.values = r.values || [],
            o = s[0] = s[0] || {};
        o.value || (o.value = e || ""), o.type || (o.type = n || "Error")
    }

    function F(t, e) {
        const n = M(t);
        if (!n) return;
        const r = n.mechanism;
        if (n.mechanism = {
                type: "generic",
                handled: !0,
                ...r,
                ...e
            }, e && "data" in e) {
            const t = { ...r && r.data,
                ...e.data
            };
            n.mechanism.data = t
        }
    }

    function H(t) {
        if (t && t.__sentry_captured__) return !0;
        try {
            D(t, "__sentry_captured__", !0)
        } catch (t) {}
        return !1
    }

    function Y(t) {
        return Array.isArray(t) ? t : [t]
    }
    const B = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
        G = [];

    function z(t) {
        const e = t.defaultIntegrations || [],
            n = t.integrations;
        let r;
        e.forEach((t => {
            t.isDefaultInstance = !0
        })), r = Array.isArray(n) ? [...e, ...n] : "function" == typeof n ? Y(n(e)) : e;
        const s = function(t) {
                const e = {};
                return t.forEach((t => {
                    const {
                        name: n
                    } = t, r = e[n];
                    r && !r.isDefaultInstance && t.isDefaultInstance || (e[n] = t)
                })), Object.values(e)
            }(r),
            o = s.findIndex((t => "Debug" === t.name));
        if (o > -1) {
            const [t] = s.splice(o, 1);
            s.push(t)
        }
        return s
    }

    function J(t, e) {
        for (const n of e) n && n.afterAllSetup && n.afterAllSetup(t)
    }

    function W(t, e, n) {
        if (n[e.name]) B && a.log(`Integration skipped because it was already installed: ${e.name}`);
        else {
            if (n[e.name] = e, -1 === G.indexOf(e.name) && "function" == typeof e.setupOnce && (e.setupOnce(), G.push(e.name)), e.setup && "function" == typeof e.setup && e.setup(t), "function" == typeof e.preprocessEvent) {
                const n = e.preprocessEvent.bind(e);
                t.on("preprocessEvent", ((e, r) => n(e, r, t)))
            }
            if ("function" == typeof e.processEvent) {
                const n = e.processEvent.bind(e),
                    r = Object.assign(((e, r) => n(e, r, t)), {
                        id: e.name
                    });
                t.addEventProcessor(r)
            }
            B && a.log(`Integration installed: ${e.name}`)
        }
    }
    const V = [/^Script error\.?$/, /^Javascript error: Script error\.? on line 0$/, /^ResizeObserver loop completed with undelivered notifications.$/, /^Cannot redefine property: googletag$/, "undefined is not an object (evaluating 'a.L')", 'can\'t redefine non-configurable property "solana"', "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)", "Can't find variable: _AutofillCallbackHandler"],
        K = (t = {}) => ({
            name: "InboundFilters",
            processEvent(e, n, r) {
                const s = r.getOptions(),
                    o = function(t = {}, e = {}) {
                        return {
                            allowUrls: [...t.allowUrls || [], ...e.allowUrls || []],
                            denyUrls: [...t.denyUrls || [], ...e.denyUrls || []],
                            ignoreErrors: [...t.ignoreErrors || [], ...e.ignoreErrors || [], ...t.disableErrorDefaults ? [] : V],
                            ignoreTransactions: [...t.ignoreTransactions || [], ...e.ignoreTransactions || []],
                            ignoreInternal: void 0 === t.ignoreInternal || t.ignoreInternal
                        }
                    }(t, s);
                return function(t, e) {
                    return e.ignoreInternal && function(t) {
                        try {
                            return "SentryError" === t.exception.values[0].type
                        } catch (t) {}
                        return !1
                    }(t) ? (B && a.warn(`Event dropped due to being internal Sentry Error.\nEvent: ${U(t)}`), !0) : function(t, e) {
                        return !(t.type || !e || !e.length) && function(t) {
                            const e = [];
                            let n;
                            t.message && e.push(t.message);
                            try {
                                n = t.exception.values[t.exception.values.length - 1]
                            } catch (t) {}
                            return n && n.value && (e.push(n.value), n.type && e.push(`${n.type}: ${n.value}`)), e
                        }(t).some((t => T(t, e)))
                    }(t, e.ignoreErrors) ? (B && a.warn(`Event dropped due to being matched by \`ignoreErrors\` option.\nEvent: ${U(t)}`), !0) : function(t) {
                        return !t.type && (!(!t.exception || !t.exception.values || 0 === t.exception.values.length) && (!t.message && !t.exception.values.some((t => t.stacktrace || t.type && "Error" !== t.type || t.value))))
                    }(t) ? (B && a.warn(`Event dropped due to not having an error message, error type or stacktrace.\nEvent: ${U(t)}`), !0) : function(t, e) {
                        if ("transaction" !== t.type || !e || !e.length) return !1;
                        const n = t.transaction;
                        return !!n && T(n, e)
                    }(t, e.ignoreTransactions) ? (B && a.warn(`Event dropped due to being matched by \`ignoreTransactions\` option.\nEvent: ${U(t)}`), !0) : function(t, e) {
                        if (!e || !e.length) return !1;
                        const n = X(t);
                        return !!n && T(n, e)
                    }(t, e.denyUrls) ? (B && a.warn(`Event dropped due to being matched by \`denyUrls\` option.\nEvent: ${U(t)}.\nUrl: ${X(t)}`), !0) : ! function(t, e) {
                        if (!e || !e.length) return !0;
                        const n = X(t);
                        return !n || T(n, e)
                    }(t, e.allowUrls) && (B && a.warn(`Event dropped due to not being matched by \`allowUrls\` option.\nEvent: ${U(t)}.\nUrl: ${X(t)}`), !0)
                }(e, o) ? null : e
            }
        });

    function X(t) {
        try {
            let e;
            try {
                e = t.exception.values[0].stacktrace.frames
            } catch (t) {}
            return e ? function(t = []) {
                for (let e = t.length - 1; e >= 0; e--) {
                    const n = t[e];
                    if (n && "<anonymous>" !== n.filename && "[native code]" !== n.filename) return n.filename || null
                }
                return null
            }(e) : null
        } catch (e) {
            return B && a.error(`Cannot extract url for event ${U(t)}`), null
        }
    }

    function Z() {
        return Q(n), n
    }

    function Q(t) {
        const n = t.__SENTRY__ = t.__SENTRY__ || {};
        return n.version = n.version || e, n[e] = n[e] || {}
    }

    function tt() {
        return {
            traceId: L(),
            spanId: L().substring(16)
        }
    }
    const et = 1e3;

    function nt() {
        return Date.now() / et
    }
    const rt = function() {
        const {
            performance: t
        } = n;
        if (!t || !t.now) return nt;
        const e = Date.now() - t.now(),
            r = null == t.timeOrigin ? e : t.timeOrigin;
        return () => (r + t.now()) / et
    }();
    let st;

    function ot(t, e = {}) {
        if (e.user && (!t.ipAddress && e.user.ip_address && (t.ipAddress = e.user.ip_address), t.did || e.did || (t.did = e.user.id || e.user.email || e.user.username)), t.timestamp = e.timestamp || rt(), e.abnormal_mechanism && (t.abnormal_mechanism = e.abnormal_mechanism), e.ignoreDuration && (t.ignoreDuration = e.ignoreDuration), e.sid && (t.sid = 32 === e.sid.length ? e.sid : L()), void 0 !== e.init && (t.init = e.init), !t.did && e.did && (t.did = `${e.did}`), "number" == typeof e.started && (t.started = e.started), t.ignoreDuration) t.duration = void 0;
        else if ("number" == typeof e.duration) t.duration = e.duration;
        else {
            const e = t.timestamp - t.started;
            t.duration = e >= 0 ? e : 0
        }
        e.release && (t.release = e.release), e.environment && (t.environment = e.environment), !t.ipAddress && e.ipAddress && (t.ipAddress = e.ipAddress), !t.userAgent && e.userAgent && (t.userAgent = e.userAgent), "number" == typeof e.errors && (t.errors = e.errors), e.status && (t.status = e.status)
    }(() => {
        const {
            performance: t
        } = n;
        if (!t || !t.now) return void(st = "none");
        const e = 36e5,
            r = t.now(),
            s = Date.now(),
            o = t.timeOrigin ? Math.abs(t.timeOrigin + r - s) : e,
            i = o < e,
            a = t.timing && t.timing.navigationStart,
            c = "number" == typeof a ? Math.abs(a + r - s) : e;
        i || c < e ? o <= c ? (st = "timeOrigin", t.timeOrigin) : st = "navigationStart" : st = "dateNow"
    })();
    const it = "_sentrySpan";

    function at(t, e) {
        e ? D(t, it, e) : delete t[it]
    }

    function ct(t) {
        return t[it]
    }
    class ut {
        constructor() {
            this._notifyingListeners = !1, this._scopeListeners = [], this._eventProcessors = [], this._breadcrumbs = [], this._attachments = [], this._user = {}, this._tags = {}, this._extra = {}, this._contexts = {}, this._sdkProcessingMetadata = {}, this._propagationContext = tt()
        }
        clone() {
            const t = new ut;
            return t._breadcrumbs = [...this._breadcrumbs], t._tags = { ...this._tags
            }, t._extra = { ...this._extra
            }, t._contexts = { ...this._contexts
            }, t._user = this._user, t._level = this._level, t._session = this._session, t._transactionName = this._transactionName, t._fingerprint = this._fingerprint, t._eventProcessors = [...this._eventProcessors], t._requestSession = this._requestSession, t._attachments = [...this._attachments], t._sdkProcessingMetadata = { ...this._sdkProcessingMetadata
            }, t._propagationContext = { ...this._propagationContext
            }, t._client = this._client, t._lastEventId = this._lastEventId, at(t, ct(this)), t
        }
        setClient(t) {
            this._client = t
        }
        setLastEventId(t) {
            this._lastEventId = t
        }
        getClient() {
            return this._client
        }
        lastEventId() {
            return this._lastEventId
        }
        addScopeListener(t) {
            this._scopeListeners.push(t)
        }
        addEventProcessor(t) {
            return this._eventProcessors.push(t), this
        }
        setUser(t) {
            return this._user = t || {
                email: void 0,
                id: void 0,
                ip_address: void 0,
                username: void 0
            }, this._session && ot(this._session, {
                user: t
            }), this._notifyScopeListeners(), this
        }
        getUser() {
            return this._user
        }
        getRequestSession() {
            return this._requestSession
        }
        setRequestSession(t) {
            return this._requestSession = t, this
        }
        setTags(t) {
            return this._tags = { ...this._tags,
                ...t
            }, this._notifyScopeListeners(), this
        }
        setTag(t, e) {
            return this._tags = { ...this._tags,
                [t]: e
            }, this._notifyScopeListeners(), this
        }
        setExtras(t) {
            return this._extra = { ...this._extra,
                ...t
            }, this._notifyScopeListeners(), this
        }
        setExtra(t, e) {
            return this._extra = { ...this._extra,
                [t]: e
            }, this._notifyScopeListeners(), this
        }
        setFingerprint(t) {
            return this._fingerprint = t, this._notifyScopeListeners(), this
        }
        setLevel(t) {
            return this._level = t, this._notifyScopeListeners(), this
        }
        setTransactionName(t) {
            return this._transactionName = t, this._notifyScopeListeners(), this
        }
        setContext(t, e) {
            return null === e ? delete this._contexts[t] : this._contexts[t] = e, this._notifyScopeListeners(), this
        }
        setSession(t) {
            return t ? this._session = t : delete this._session, this._notifyScopeListeners(), this
        }
        getSession() {
            return this._session
        }
        update(t) {
            if (!t) return this;
            const e = "function" == typeof t ? t(this) : t,
                [n, r] = e instanceof lt ? [e.getScopeData(), e.getRequestSession()] : _(e) ? [t, t.requestSession] : [],
                {
                    tags: s,
                    extra: o,
                    user: i,
                    contexts: a,
                    level: c,
                    fingerprint: u = [],
                    propagationContext: l
                } = n || {};
            return this._tags = { ...this._tags,
                ...s
            }, this._extra = { ...this._extra,
                ...o
            }, this._contexts = { ...this._contexts,
                ...a
            }, i && Object.keys(i).length && (this._user = i), c && (this._level = c), u.length && (this._fingerprint = u), l && (this._propagationContext = l), r && (this._requestSession = r), this
        }
        clear() {
            return this._breadcrumbs = [], this._tags = {}, this._extra = {}, this._user = {}, this._contexts = {}, this._level = void 0, this._transactionName = void 0, this._fingerprint = void 0, this._requestSession = void 0, this._session = void 0, at(this, void 0), this._attachments = [], this._propagationContext = tt(), this._notifyScopeListeners(), this
        }
        addBreadcrumb(t, e) {
            const n = "number" == typeof e ? e : 100;
            if (n <= 0) return this;
            const r = {
                    timestamp: nt(),
                    ...t
                },
                s = this._breadcrumbs;
            return s.push(r), this._breadcrumbs = s.length > n ? s.slice(-n) : s, this._notifyScopeListeners(), this
        }
        getLastBreadcrumb() {
            return this._breadcrumbs[this._breadcrumbs.length - 1]
        }
        clearBreadcrumbs() {
            return this._breadcrumbs = [], this._notifyScopeListeners(), this
        }
        addAttachment(t) {
            return this._attachments.push(t), this
        }
        clearAttachments() {
            return this._attachments = [], this
        }
        getScopeData() {
            return {
                breadcrumbs: this._breadcrumbs,
                attachments: this._attachments,
                contexts: this._contexts,
                tags: this._tags,
                extra: this._extra,
                user: this._user,
                level: this._level,
                fingerprint: this._fingerprint || [],
                eventProcessors: this._eventProcessors,
                propagationContext: this._propagationContext,
                sdkProcessingMetadata: this._sdkProcessingMetadata,
                transactionName: this._transactionName,
                span: ct(this)
            }
        }
        setSDKProcessingMetadata(t) {
            return this._sdkProcessingMetadata = { ...this._sdkProcessingMetadata,
                ...t
            }, this
        }
        setPropagationContext(t) {
            return this._propagationContext = t, this
        }
        getPropagationContext() {
            return this._propagationContext
        }
        captureException(t, e) {
            const n = e && e.event_id ? e.event_id : L();
            if (!this._client) return a.warn("No client configured on scope - will not capture exception!"), n;
            const r = new Error("Sentry syntheticException");
            return this._client.captureException(t, {
                originalException: t,
                syntheticException: r,
                ...e,
                event_id: n
            }, this), n
        }
        captureMessage(t, e, n) {
            const r = n && n.event_id ? n.event_id : L();
            if (!this._client) return a.warn("No client configured on scope - will not capture message!"), r;
            const s = new Error(t);
            return this._client.captureMessage(t, e, {
                originalException: t,
                syntheticException: s,
                ...n,
                event_id: r
            }, this), r
        }
        captureEvent(t, e) {
            const n = e && e.event_id ? e.event_id : L();
            return this._client ? (this._client.captureEvent(t, { ...e,
                event_id: n
            }, this), n) : (a.warn("No client configured on scope - will not capture event!"), n)
        }
        _notifyScopeListeners() {
            this._notifyingListeners || (this._notifyingListeners = !0, this._scopeListeners.forEach((t => {
                t(this)
            })), this._notifyingListeners = !1)
        }
    }
    const lt = ut;
    class pt {
        constructor(t, e) {
            let n, r;
            n = t || new lt, r = e || new lt, this._stack = [{
                scope: n
            }], this._isolationScope = r
        }
        withScope(t) {
            const e = this._pushScope();
            let n;
            try {
                n = t(e)
            } catch (t) {
                throw this._popScope(), t
            }
            return y(n) ? n.then((t => (this._popScope(), t)), (t => {
                throw this._popScope(), t
            })) : (this._popScope(), n)
        }
        getClient() {
            return this.getStackTop().client
        }
        getScope() {
            return this.getStackTop().scope
        }
        getIsolationScope() {
            return this._isolationScope
        }
        getStackTop() {
            return this._stack[this._stack.length - 1]
        }
        _pushScope() {
            const t = this.getScope().clone();
            return this._stack.push({
                client: this.getClient(),
                scope: t
            }), t
        }
        _popScope() {
            return !(this._stack.length <= 1 || !this._stack.pop())
        }
    }

    function dt() {
        const t = Q(Z());
        return t.stack = t.stack || new pt(r("defaultCurrentScope", (() => new lt)), r("defaultIsolationScope", (() => new lt)))
    }

    function ft(t) {
        return dt().withScope(t)
    }

    function ht(t, e) {
        const n = dt();
        return n.withScope((() => (n.getStackTop().scope = t, e(t))))
    }

    function mt(t) {
        return dt().withScope((() => t(dt().getIsolationScope())))
    }

    function _t(t) {
        const e = Q(t);
        return e.acs ? e.acs : {
            withIsolationScope: mt,
            withScope: ft,
            withSetScope: ht,
            withSetIsolationScope: (t, e) => mt(e),
            getCurrentScope: () => dt().getScope(),
            getIsolationScope: () => dt().getIsolationScope()
        }
    }

    function gt() {
        return _t(Z()).getCurrentScope()
    }

    function yt() {
        return _t(Z()).getIsolationScope()
    }

    function vt() {
        return gt().getClient()
    }
    let bt;
    const Et = new WeakMap,
        St = () => ({
            name: "FunctionToString",
            setupOnce() {
                bt = Function.prototype.toString;
                try {
                    Function.prototype.toString = function(...t) {
                        const e = I(this),
                            n = Et.has(vt()) && void 0 !== e ? e : this;
                        return bt.apply(n, t)
                    }
                } catch (t) {}
            },
            setup(t) {
                Et.set(t, !0)
            }
        }),
        xt = 50,
        wt = "?",
        kt = /\(error: (.*)\)/,
        Ot = /captureMessage|captureException/;

    function Tt(...t) {
        const e = t.sort(((t, e) => t[0] - e[0])).map((t => t[1]));
        return (t, n = 0, r = 0) => {
            const s = [],
                o = t.split("\n");
            for (let t = n; t < o.length; t++) {
                const n = o[t];
                if (n.length > 1024) continue;
                const i = kt.test(n) ? n.replace(kt, "$1") : n;
                if (!i.match(/\S*Error: /)) {
                    for (const t of e) {
                        const e = t(i);
                        if (e) {
                            s.push(e);
                            break
                        }
                    }
                    if (s.length >= xt + r) break
                }
            }
            return function(t) {
                if (!t.length) return [];
                const e = Array.from(t);
                return /sentryWrapped/.test($t(e).function || "") && e.pop(), e.reverse(), Ot.test($t(e).function || "") && (e.pop(), Ot.test($t(e).function || "") && e.pop()), e.slice(0, xt).map((t => ({ ...t,
                    filename: t.filename || $t(e).filename,
                    function: t.function || wt
                })))
            }(s.slice(r))
        }
    }

    function $t(t) {
        return t[t.length - 1] || {}
    }
    const Dt = "<anonymous>";

    function Nt(t) {
        try {
            return t && "function" == typeof t && t.name || Dt
        } catch (t) {
            return Dt
        }
    }

    function It(t) {
        const e = t.exception;
        if (e) {
            const t = [];
            try {
                return e.values.forEach((e => {
                    e.stacktrace.frames && t.push(...e.stacktrace.frames)
                })), t
            } catch (t) {
                return
            }
        }
    }
    const Pt = () => {
        let t;
        return {
            name: "Dedupe",
            processEvent(e) {
                if (e.type) return e;
                try {
                    if (function(t, e) {
                            return !!e && (!! function(t, e) {
                                const n = t.message,
                                    r = e.message;
                                return !(!n && !r) && (!(n && !r || !n && r) && (n === r && (!!Rt(t, e) && !!jt(t, e))))
                            }(t, e) || !! function(t, e) {
                                const n = Ct(e),
                                    r = Ct(t);
                                return !(!n || !r) && (n.type === r.type && n.value === r.value && (!!Rt(t, e) && !!jt(t, e)))
                            }(t, e))
                        }(e, t)) return B && a.warn("Event dropped due to being a duplicate of previously captured event."), null
                } catch (t) {}
                return t = e
            }
        }
    };

    function jt(t, e) {
        let n = It(t),
            r = It(e);
        if (!n && !r) return !0;
        if (n && !r || !n && r) return !1;
        if (r.length !== n.length) return !1;
        for (let t = 0; t < r.length; t++) {
            const e = r[t],
                s = n[t];
            if (e.filename !== s.filename || e.lineno !== s.lineno || e.colno !== s.colno || e.function !== s.function) return !1
        }
        return !0
    }

    function Rt(t, e) {
        let n = t.fingerprint,
            r = e.fingerprint;
        if (!n && !r) return !0;
        if (n && !r || !n && r) return !1;
        try {
            return !(n.join("") !== r.join(""))
        } catch (t) {
            return !1
        }
    }

    function Ct(t) {
        return t.exception && t.exception.values && t.exception.values[0]
    }
    const At = "production";

    function Lt(t, e = 100, n = 1 / 0) {
        try {
            return Ut("", t, e, n)
        } catch (t) {
            return {
                ERROR: `**non-serializable** (${t})`
            }
        }
    }

    function Mt(t, e = 3, n = 102400) {
        const r = Lt(t, e);
        return s = r,
            function(t) {
                return ~-encodeURI(t).split(/%..|./).length
            }(JSON.stringify(s)) > n ? Mt(t, e - 1, n) : r;
        var s
    }

    function Ut(t, e, n = 1 / 0, r = 1 / 0, s = function() {
        const t = "function" == typeof WeakSet,
            e = t ? new WeakSet : [];
        return [function(n) {
            if (t) return !!e.has(n) || (e.add(n), !1);
            for (let t = 0; t < e.length; t++)
                if (e[t] === n) return !0;
            return e.push(n), !1
        }, function(n) {
            if (t) e.delete(n);
            else
                for (let t = 0; t < e.length; t++)
                    if (e[t] === n) {
                        e.splice(t, 1);
                        break
                    }
        }]
    }()) {
        const [o, i] = s;
        if (null == e || ["number", "boolean", "string"].includes(typeof e) && !Number.isNaN(e)) return e;
        const a = function(t, e) {
            try {
                if ("domain" === t && e && "object" == typeof e && e._events) return "[Domain]";
                if ("domainEmitter" === t) return "[DomainEmitter]";
                if ("undefined" != typeof global && e === global) return "[Global]";
                if ("undefined" != typeof window && e === window) return "[Window]";
                if ("undefined" != typeof document && e === document) return "[Document]";
                if (b(e)) return "[VueViewModel]";
                if (_(n = e) && "nativeEvent" in n && "preventDefault" in n && "stopPropagation" in n) return "[SyntheticEvent]";
                if ("number" == typeof e && e != e) return "[NaN]";
                if ("function" == typeof e) return `[Function: ${Nt(e)}]`;
                if ("symbol" == typeof e) return `[${String(e)}]`;
                if ("bigint" == typeof e) return `[BigInt: ${String(e)}]`;
                const r = function(t) {
                    const e = Object.getPrototypeOf(t);
                    return e ? e.constructor.name : "null prototype"
                }(e);
                return /^HTML(\w*)Element$/.test(r) ? `[HTMLElement: ${r}]` : `[object ${r}]`
            } catch (t) {
                return `**non-serializable** (${t})`
            }
            var n
        }(t, e);
        if (!a.startsWith("[object ")) return a;
        if (e.__sentry_skip_normalization__) return e;
        const c = "number" == typeof e.__sentry_override_normalization_depth__ ? e.__sentry_override_normalization_depth__ : n;
        if (0 === c) return a.replace("object ", "");
        if (o(e)) return "[Circular ~]";
        const u = e;
        if (u && "function" == typeof u.toJSON) try {
            return Ut("", u.toJSON(), c - 1, r, s)
        } catch (t) {}
        const l = Array.isArray(e) ? [] : {};
        let p = 0;
        const d = P(e);
        for (const t in d) {
            if (!Object.prototype.hasOwnProperty.call(d, t)) continue;
            if (p >= r) {
                l[t] = "[MaxProperties ~]";
                break
            }
            const e = d[t];
            l[t] = Ut(t, e, c - 1, r, s), p++
        }
        return i(e), l
    }
    var qt;

    function Ft(t) {
        return new Yt((e => {
            e(t)
        }))
    }

    function Ht(t) {
        return new Yt(((e, n) => {
            n(t)
        }))
    }! function(t) {
        t[t.PENDING = 0] = "PENDING", t[t.RESOLVED = 1] = "RESOLVED", t[t.REJECTED = 2] = "REJECTED"
    }(qt || (qt = {}));
    class Yt {
        constructor(t) {
            Yt.prototype.__init.call(this), Yt.prototype.__init2.call(this), Yt.prototype.__init3.call(this), Yt.prototype.__init4.call(this), this._state = qt.PENDING, this._handlers = [];
            try {
                t(this._resolve, this._reject)
            } catch (t) {
                this._reject(t)
            }
        }
        then(t, e) {
            return new Yt(((n, r) => {
                this._handlers.push([!1, e => {
                    if (t) try {
                        n(t(e))
                    } catch (t) {
                        r(t)
                    } else n(e)
                }, t => {
                    if (e) try {
                        n(e(t))
                    } catch (t) {
                        r(t)
                    } else r(t)
                }]), this._executeHandlers()
            }))
        } catch (t) {
            return this.then((t => t), t)
        } finally(t) {
            return new Yt(((e, n) => {
                let r, s;
                return this.then((e => {
                    s = !1, r = e, t && t()
                }), (e => {
                    s = !0, r = e, t && t()
                })).then((() => {
                    s ? n(r) : e(r)
                }))
            }))
        }
        __init() {
            this._resolve = t => {
                this._setResult(qt.RESOLVED, t)
            }
        }
        __init2() {
            this._reject = t => {
                this._setResult(qt.REJECTED, t)
            }
        }
        __init3() {
            this._setResult = (t, e) => {
                this._state === qt.PENDING && (y(e) ? e.then(this._resolve, this._reject) : (this._state = t, this._value = e, this._executeHandlers()))
            }
        }
        __init4() {
            this._executeHandlers = () => {
                if (this._state === qt.PENDING) return;
                const t = this._handlers.slice();
                this._handlers = [], t.forEach((t => {
                    t[0] || (this._state === qt.RESOLVED && t[1](this._value), this._state === qt.REJECTED && t[2](this._value), t[0] = !0)
                }))
            }
        }
    }

    function Bt(t, e, n, r = 0) {
        return new Yt(((s, o) => {
            const i = t[r];
            if (null === e || "function" != typeof i) s(e);
            else {
                const c = i({ ...e
                }, n);
                B && i.id && null === c && a.log(`Event processor "${i.id}" dropped event`), y(c) ? c.then((e => Bt(t, e, n, r + 1).then(s))).then(null, o) : Bt(t, c, n, r + 1).then(s).then(null, o)
            }
        }))
    }
    const Gt = "sentry-",
        zt = /^sentry-/;

    function Jt(t) {
        return t.split(",").map((t => t.split("=").map((t => decodeURIComponent(t.trim()))))).reduce(((t, [e, n]) => (e && n && (t[e] = n), t)), {})
    }
    const Wt = "sentry.source",
        Vt = "sentry.sample_rate",
        Kt = "sentry.op",
        Xt = "sentry.origin",
        Zt = "_sentryMetrics";

    function Qt(t) {
        const e = t[Zt];
        if (!e) return;
        const n = {};
        for (const [, [t, r]] of e)(n[t] || (n[t] = [])).push(C(r));
        return n
    }
    const te = 0,
        ee = 1,
        ne = 1;

    function re(t) {
        const {
            spanId: e,
            traceId: n
        } = t.spanContext(), {
            parent_span_id: r
        } = ie(t);
        return C({
            parent_span_id: r,
            span_id: e,
            trace_id: n
        })
    }

    function se(t) {
        return "number" == typeof t ? oe(t) : Array.isArray(t) ? t[0] + t[1] / 1e9 : t instanceof Date ? oe(t.getTime()) : rt()
    }

    function oe(t) {
        return t > 9999999999 ? t / 1e3 : t
    }

    function ie(t) {
        if (function(t) {
                return "function" == typeof t.getSpanJSON
            }(t)) return t.getSpanJSON();
        try {
            const {
                spanId: e,
                traceId: n
            } = t.spanContext();
            if (function(t) {
                    const e = t;
                    return !!(e.attributes && e.startTime && e.name && e.endTime && e.status)
                }(t)) {
                const {
                    attributes: r,
                    startTime: s,
                    name: o,
                    endTime: i,
                    parentSpanId: a,
                    status: c
                } = t;
                return C({
                    span_id: e,
                    trace_id: n,
                    data: r,
                    description: o,
                    parent_span_id: a,
                    start_timestamp: se(s),
                    timestamp: se(i) || void 0,
                    status: ae(c),
                    op: r[Kt],
                    origin: r[Xt],
                    _metrics_summary: Qt(t)
                })
            }
            return {
                span_id: e,
                trace_id: n
            }
        } catch (t) {
            return {}
        }
    }

    function ae(t) {
        if (t && t.code !== te) return t.code === ee ? "ok" : t.message || "unknown_error"
    }
    const ce = "_sentryRootSpan";

    function ue(t) {
        return t[ce] || t
    }
    const le = "_frozenDsc";

    function pe(t, e) {
        const n = e.getOptions(),
            {
                publicKey: r
            } = e.getDsn() || {},
            s = C({
                environment: n.environment || At,
                release: n.release,
                public_key: r,
                trace_id: t
            });
        return e.emit("createDsc", s), s
    }

    function de(t) {
        const e = vt();
        if (!e) return {};
        const n = pe(ie(t).trace_id || "", e),
            r = ue(t),
            s = r[le];
        if (s) return s;
        const o = r.spanContext().traceState,
            i = o && o.get("sentry.dsc"),
            a = i && function(t) {
                const e = function(t) {
                    if (t && (f(t) || Array.isArray(t))) return Array.isArray(t) ? t.reduce(((t, e) => {
                        const n = Jt(e);
                        return Object.entries(n).forEach((([e, n]) => {
                            t[e] = n
                        })), t
                    }), {}) : Jt(t)
                }(t);
                if (!e) return;
                const n = Object.entries(e).reduce(((t, [e, n]) => (e.match(zt) && (t[e.slice(Gt.length)] = n), t)), {});
                return Object.keys(n).length > 0 ? n : void 0
            }(i);
        if (a) return a;
        const c = ie(r),
            u = c.data || {},
            l = u[Vt];
        null != l && (n.sample_rate = `${l}`);
        const p = u[Wt],
            d = c.description;
        return "url" !== p && d && (n.transaction = d), n.sampled = String(function(t) {
            const {
                traceFlags: e
            } = t.spanContext();
            return e === ne
        }(r)), e.emit("createDsc", n, r), n
    }

    function fe(t, e) {
        const {
            extra: n,
            tags: r,
            user: s,
            contexts: o,
            level: i,
            sdkProcessingMetadata: a,
            breadcrumbs: c,
            fingerprint: u,
            eventProcessors: l,
            attachments: p,
            propagationContext: d,
            transactionName: f,
            span: h
        } = e;
        he(t, "extra", n), he(t, "tags", r), he(t, "user", s), he(t, "contexts", o), he(t, "sdkProcessingMetadata", a), i && (t.level = i), f && (t.transactionName = f), h && (t.span = h), c.length && (t.breadcrumbs = [...t.breadcrumbs, ...c]), u.length && (t.fingerprint = [...t.fingerprint, ...u]), l.length && (t.eventProcessors = [...t.eventProcessors, ...l]), p.length && (t.attachments = [...t.attachments, ...p]), t.propagationContext = { ...t.propagationContext,
            ...d
        }
    }

    function he(t, e, n) {
        if (n && Object.keys(n).length) {
            t[e] = { ...t[e]
            };
            for (const r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[e][r] = n[r])
        }
    }

    function me(t, e, s, o, i, a) {
        const {
            normalizeDepth: c = 3,
            normalizeMaxBreadth: u = 1e3
        } = t, l = { ...e,
            event_id: e.event_id || s.event_id || L(),
            timestamp: e.timestamp || nt()
        }, p = s.integrations || t.integrations.map((t => t.name));
        ! function(t, e) {
            const {
                environment: n,
                release: r,
                dist: s,
                maxValueLength: o = 250
            } = e;
            "environment" in t || (t.environment = "environment" in e ? n : At), void 0 === t.release && void 0 !== r && (t.release = r), void 0 === t.dist && void 0 !== s && (t.dist = s), t.message && (t.message = k(t.message, o));
            const i = t.exception && t.exception.values && t.exception.values[0];
            i && i.value && (i.value = k(i.value, o));
            const a = t.request;
            a && a.url && (a.url = k(a.url, o))
        }(l, t),
        function(t, e) {
            e.length > 0 && (t.sdk = t.sdk || {}, t.sdk.integrations = [...t.sdk.integrations || [], ...e])
        }(l, p), i && i.emit("applyFrameMetadata", e), void 0 === e.type && function(t, e) {
            const r = n._sentryDebugIds;
            if (!r) return;
            let s;
            const o = _e.get(e);
            o ? s = o : (s = new Map, _e.set(e, s));
            const i = Object.entries(r).reduce(((t, [n, r]) => {
                let o;
                const i = s.get(n);
                i ? o = i : (o = e(n), s.set(n, o));
                for (let e = o.length - 1; e >= 0; e--) {
                    const n = o[e];
                    if (n.filename) {
                        t[n.filename] = r;
                        break
                    }
                }
                return t
            }), {});
            try {
                t.exception.values.forEach((t => {
                    t.stacktrace.frames.forEach((t => {
                        t.filename && (t.debug_id = i[t.filename])
                    }))
                }))
            } catch (t) {}
        }(l, t.stackParser);
        const d = function(t, e) {
            if (!e) return t;
            const n = t ? t.clone() : new lt;
            return n.update(e), n
        }(o, s.captureContext);
        s.mechanism && F(l, s.mechanism);
        const f = i ? i.getEventProcessors() : [],
            h = r("globalScope", (() => new lt)).getScopeData();
        a && fe(h, a.getScopeData()), d && fe(h, d.getScopeData());
        const m = [...s.attachments || [], ...h.attachments];
        return m.length && (s.attachments = m),
            function(t, e) {
                const {
                    fingerprint: n,
                    span: r,
                    breadcrumbs: s,
                    sdkProcessingMetadata: o
                } = e;
                ! function(t, e) {
                    const {
                        extra: n,
                        tags: r,
                        user: s,
                        contexts: o,
                        level: i,
                        transactionName: a
                    } = e, c = C(n);
                    c && Object.keys(c).length && (t.extra = { ...c,
                        ...t.extra
                    });
                    const u = C(r);
                    u && Object.keys(u).length && (t.tags = { ...u,
                        ...t.tags
                    });
                    const l = C(s);
                    l && Object.keys(l).length && (t.user = { ...l,
                        ...t.user
                    });
                    const p = C(o);
                    p && Object.keys(p).length && (t.contexts = { ...p,
                        ...t.contexts
                    }), i && (t.level = i), a && "transaction" !== t.type && (t.transaction = a)
                }(t, e), r && function(t, e) {
                        t.contexts = {
                            trace: re(e),
                            ...t.contexts
                        }, t.sdkProcessingMetadata = {
                            dynamicSamplingContext: de(e),
                            ...t.sdkProcessingMetadata
                        };
                        const n = ie(ue(e)).description;
                        n && !t.transaction && "transaction" === t.type && (t.transaction = n)
                    }(t, r),
                    function(t, e) {
                        t.fingerprint = t.fingerprint ? Y(t.fingerprint) : [], e && (t.fingerprint = t.fingerprint.concat(e)), t.fingerprint && !t.fingerprint.length && delete t.fingerprint
                    }(t, n),
                    function(t, e) {
                        const n = [...t.breadcrumbs || [], ...e];
                        t.breadcrumbs = n.length ? n : void 0
                    }(t, s),
                    function(t, e) {
                        t.sdkProcessingMetadata = { ...t.sdkProcessingMetadata,
                            ...e
                        }
                    }(t, o)
            }(l, h), Bt([...f, ...h.eventProcessors], l, s).then((t => (t && function(t) {
                const e = {};
                try {
                    t.exception.values.forEach((t => {
                        t.stacktrace.frames.forEach((t => {
                            t.debug_id && (t.abs_path ? e[t.abs_path] = t.debug_id : t.filename && (e[t.filename] = t.debug_id), delete t.debug_id)
                        }))
                    }))
                } catch (t) {}
                if (0 === Object.keys(e).length) return;
                t.debug_meta = t.debug_meta || {}, t.debug_meta.images = t.debug_meta.images || [];
                const n = t.debug_meta.images;
                Object.entries(e).forEach((([t, e]) => {
                    n.push({
                        type: "sourcemap",
                        code_file: t,
                        debug_id: e
                    })
                }))
            }(t), "number" == typeof c && c > 0 ? function(t, e, n) {
                if (!t) return null;
                const r = { ...t,
                    ...t.breadcrumbs && {
                        breadcrumbs: t.breadcrumbs.map((t => ({ ...t,
                            ...t.data && {
                                data: Lt(t.data, e, n)
                            }
                        })))
                    },
                    ...t.user && {
                        user: Lt(t.user, e, n)
                    },
                    ...t.contexts && {
                        contexts: Lt(t.contexts, e, n)
                    },
                    ...t.extra && {
                        extra: Lt(t.extra, e, n)
                    }
                };
                return t.contexts && t.contexts.trace && r.contexts && (r.contexts.trace = t.contexts.trace, t.contexts.trace.data && (r.contexts.trace.data = Lt(t.contexts.trace.data, e, n))), t.spans && (r.spans = t.spans.map((t => ({ ...t,
                    ...t.data && {
                        data: Lt(t.data, e, n)
                    }
                })))), r
            }(t, c, u) : t)))
    }
    const _e = new WeakMap;
    const ge = ["user", "level", "extra", "contexts", "tags", "fingerprint", "requestSession", "propagationContext"];

    function ye(t, e) {
        return gt().captureEvent(t, e)
    }

    function ve(t) {
        const e = vt(),
            r = yt(),
            s = gt(),
            {
                release: o,
                environment: i = At
            } = e && e.getOptions() || {},
            {
                userAgent: a
            } = n.navigator || {},
            c = function(t) {
                const e = rt(),
                    n = {
                        sid: L(),
                        init: !0,
                        timestamp: e,
                        started: e,
                        duration: 0,
                        status: "ok",
                        errors: 0,
                        ignoreDuration: !1,
                        toJSON: () => function(t) {
                            return C({
                                sid: `${t.sid}`,
                                init: t.init,
                                started: new Date(1e3 * t.started).toISOString(),
                                timestamp: new Date(1e3 * t.timestamp).toISOString(),
                                status: t.status,
                                errors: t.errors,
                                did: "number" == typeof t.did || "string" == typeof t.did ? `${t.did}` : void 0,
                                duration: t.duration,
                                abnormal_mechanism: t.abnormal_mechanism,
                                attrs: {
                                    release: t.release,
                                    environment: t.environment,
                                    ip_address: t.ipAddress,
                                    user_agent: t.userAgent
                                }
                            })
                        }(n)
                    };
                return t && ot(n, t), n
            }({
                release: o,
                environment: i,
                user: s.getUser() || r.getUser(),
                ...a && {
                    userAgent: a
                },
                ...t
            }),
            u = r.getSession();
        return u && "ok" === u.status && ot(u, {
            status: "exited"
        }), be(), r.setSession(c), s.setSession(c), c
    }

    function be() {
        const t = yt(),
            e = gt(),
            n = e.getSession() || t.getSession();
        n && function(t, e) {
            let n = {};
            "ok" === t.status && (n = {
                status: "exited"
            }), ot(t, n)
        }(n), Ee(), t.setSession(), e.setSession()
    }

    function Ee() {
        const t = yt(),
            e = gt(),
            n = vt(),
            r = e.getSession() || t.getSession();
        r && n && n.captureSession(r)
    }

    function Se(t = !1) {
        t ? be() : Ee()
    }
    const xe = n;

    function we() {
        if (!("fetch" in xe)) return !1;
        try {
            return new Headers, new Request("http://www.example.com"), new Response, !0
        } catch (t) {
            return !1
        }
    }

    function ke(t) {
        return t && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(t.toString())
    }
    const Oe = {},
        Te = {};

    function $e(t, e) {
        Oe[t] = Oe[t] || [], Oe[t].push(e)
    }

    function De(t, e) {
        Te[t] || (e(), Te[t] = !0)
    }

    function Ne(e, n) {
        const r = e && Oe[e];
        if (r)
            for (const s of r) try {
                s(n)
            } catch (n) {
                t && a.error(`Error while triggering instrumentation handler.\nType: ${e}\nName: ${Nt(s)}\nError:`, n)
            }
    }
    const Ie = n,
        Pe = n;
    let je;

    function Re(t) {
        const e = "history";
        $e(e, t), De(e, Ce)
    }

    function Ce() {
        if (! function() {
                const t = Ie.chrome,
                    e = t && t.app && t.app.runtime,
                    n = "history" in Ie && !!Ie.history.pushState && !!Ie.history.replaceState;
                return !e && n
            }()) return;
        const t = Pe.onpopstate;

        function e(t) {
            return function(...e) {
                const n = e.length > 2 ? e[2] : void 0;
                if (n) {
                    const t = je,
                        e = String(n);
                    je = e, Ne("history", {
                        from: t,
                        to: e
                    })
                }
                return t.apply(this, e)
            }
        }
        Pe.onpopstate = function(...e) {
            const n = Pe.location.href,
                r = je;
            if (je = n, Ne("history", {
                    from: r,
                    to: n
                }), t) try {
                return t.apply(this, e)
            } catch (t) {}
        }, $(Pe.history, "pushState", e), $(Pe.history, "replaceState", e)
    }
    const Ae = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;

    function Le(t, e = !1) {
        const {
            host: n,
            path: r,
            pass: s,
            port: o,
            projectId: i,
            protocol: a,
            publicKey: c
        } = t;
        return `${a}://${c}${e&&s?`:${s}`:""}@${n}${o?`:${o}`:""}/${r?`${r}/`:r}${i}`
    }

    function Me(t) {
        return {
            protocol: t.protocol,
            publicKey: t.publicKey || "",
            pass: t.pass || "",
            host: t.host,
            port: t.port || "",
            path: t.path || "",
            projectId: t.projectId
        }
    }

    function Ue(t, e = []) {
        return [t, e]
    }

    function qe(t, e) {
        const [n, r] = t;
        return [n, [...r, e]]
    }

    function Fe(t, e) {
        const n = t[1];
        for (const t of n)
            if (e(t, t[0].type)) return !0;
        return !1
    }

    function He(t) {
        return n.__SENTRY__ && n.__SENTRY__.encodePolyfill ? n.__SENTRY__.encodePolyfill(t) : (new TextEncoder).encode(t)
    }

    function Ye(t) {
        const [e, n] = t;
        let r = JSON.stringify(e);

        function s(t) {
            "string" == typeof r ? r = "string" == typeof t ? r + t : [He(r), t] : r.push("string" == typeof t ? He(t) : t)
        }
        for (const t of n) {
            const [e, n] = t;
            if (s(`\n${JSON.stringify(e)}\n`), "string" == typeof n || n instanceof Uint8Array) s(n);
            else {
                let t;
                try {
                    t = JSON.stringify(n)
                } catch (e) {
                    t = JSON.stringify(Lt(n))
                }
                s(t)
            }
        }
        return "string" == typeof r ? r : function(t) {
            const e = t.reduce(((t, e) => t + e.length), 0),
                n = new Uint8Array(e);
            let r = 0;
            for (const e of t) n.set(e, r), r += e.length;
            return n
        }(r)
    }

    function Be(t) {
        const e = "string" == typeof t.data ? He(t.data) : t.data;
        return [C({
            type: "attachment",
            length: e.length,
            filename: t.filename,
            content_type: t.contentType,
            attachment_type: t.attachmentType
        }), e]
    }
    const Ge = {
        session: "session",
        sessions: "session",
        attachment: "attachment",
        transaction: "transaction",
        event: "error",
        client_report: "internal",
        user_report: "default",
        profile: "profile",
        profile_chunk: "profile",
        replay_event: "replay",
        replay_recording: "replay",
        check_in: "monitor",
        feedback: "feedback",
        span: "span",
        statsd: "metric_bucket"
    };

    function ze(t) {
        return Ge[t]
    }

    function Je(t) {
        if (!t || !t.sdk) return;
        const {
            name: e,
            version: n
        } = t.sdk;
        return {
            name: e,
            version: n
        }
    }
    class We extends Error {
        constructor(t, e = "warn") {
            super(t), this.message = t, this.name = new.target.prototype.constructor.name, Object.setPrototypeOf(this, new.target.prototype), this.logLevel = e
        }
    }
    const Ve = "7";

    function Ke(t, e, n) {
        return e || `${function(t){return`${function(t){const e=t.protocol?`${t.protocol}:`:"",n=t.port?`:${t.port}`:"";return`${e}//${t.host}${n}${t.path?`/${t.path}`:""}/api/`}(t)}${t.projectId}/envelope/`}(t)}?${function(t,e){return n={sentry_key:t.publicKey,sentry_version:Ve,...e&&{sentry_client:`${e.name}/${e.version}`}},Object.keys(n).map((t=>`
        $ {
            encodeURIComponent(t)
        } = $ {
            encodeURIComponent(n[t])
        }
        `)).join("&");var n}(t,n)}`
    }
    const Xe = "Not capturing exception because it's already been captured.";
    class Ze {
        constructor(e) {
            if (this._options = e, this._integrations = {}, this._numProcessing = 0, this._outcomes = {}, this._hooks = {}, this._eventProcessors = [], e.dsn ? this._dsn = function(e) {
                    const n = "string" == typeof e ? function(t) {
                        const e = Ae.exec(t);
                        if (!e) return void i((() => {
                            console.error(`Invalid Sentry Dsn: ${t}`)
                        }));
                        const [n, r, s = "", o = "", a = "", c = ""] = e.slice(1);
                        let u = "",
                            l = c;
                        const p = l.split("/");
                        if (p.length > 1 && (u = p.slice(0, -1).join("/"), l = p.pop()), l) {
                            const t = l.match(/^\d+/);
                            t && (l = t[0])
                        }
                        return Me({
                            host: o,
                            pass: s,
                            path: u,
                            projectId: l,
                            port: a,
                            protocol: n,
                            publicKey: r
                        })
                    }(e) : Me(e);
                    if (n && function(e) {
                            if (!t) return !0;
                            const {
                                port: n,
                                projectId: r,
                                protocol: s
                            } = e;
                            return !(["protocol", "publicKey", "host", "projectId"].find((t => !e[t] && (a.error(`Invalid Sentry Dsn: ${t} missing`), !0))) || (r.match(/^\d+$/) ? function(t) {
                                return "http" === t || "https" === t
                            }(s) ? n && isNaN(parseInt(n, 10)) && (a.error(`Invalid Sentry Dsn: Invalid port ${n}`), 1) : (a.error(`Invalid Sentry Dsn: Invalid protocol ${s}`), 1) : (a.error(`Invalid Sentry Dsn: Invalid projectId ${r}`), 1)))
                        }(n)) return n
                }(e.dsn) : B && a.warn("No DSN provided, client will not send events."), this._dsn) {
                const t = Ke(this._dsn, e.tunnel, e._metadata ? e._metadata.sdk : void 0);
                this._transport = e.transport({
                    tunnel: this._options.tunnel,
                    recordDroppedEvent: this.recordDroppedEvent.bind(this),
                    ...e.transportOptions,
                    url: t
                })
            }
        }
        captureException(t, e, n) {
            const r = L();
            if (H(t)) return B && a.log(Xe), r;
            const s = {
                event_id: r,
                ...e
            };
            return this._process(this.eventFromException(t, s).then((t => this._captureEvent(t, s, n)))), s.event_id
        }
        captureMessage(t, e, n, r) {
            const s = {
                    event_id: L(),
                    ...n
                },
                o = h(t) ? t : String(t),
                i = m(t) ? this.eventFromMessage(o, e, s) : this.eventFromException(t, s);
            return this._process(i.then((t => this._captureEvent(t, s, r)))), s.event_id
        }
        captureEvent(t, e, n) {
            const r = L();
            if (e && e.originalException && H(e.originalException)) return B && a.log(Xe), r;
            const s = {
                    event_id: r,
                    ...e
                },
                o = (t.sdkProcessingMetadata || {}).capturedSpanScope;
            return this._process(this._captureEvent(t, s, o || n)), s.event_id
        }
        captureSession(t) {
            "string" != typeof t.release ? B && a.warn("Discarded session because of missing or non-string release") : (this.sendSession(t), ot(t, {
                init: !1
            }))
        }
        getDsn() {
            return this._dsn
        }
        getOptions() {
            return this._options
        }
        getSdkMetadata() {
            return this._options._metadata
        }
        getTransport() {
            return this._transport
        }
        flush(t) {
            const e = this._transport;
            return e ? (this.emit("flush"), this._isClientDoneProcessing(t).then((n => e.flush(t).then((t => n && t))))) : Ft(!0)
        }
        close(t) {
            return this.flush(t).then((t => (this.getOptions().enabled = !1, this.emit("close"), t)))
        }
        getEventProcessors() {
            return this._eventProcessors
        }
        addEventProcessor(t) {
            this._eventProcessors.push(t)
        }
        init() {
            this._isEnabled() && this._setupIntegrations()
        }
        getIntegrationByName(t) {
            return this._integrations[t]
        }
        addIntegration(t) {
            const e = this._integrations[t.name];
            W(this, t, this._integrations), e || J(this, [t])
        }
        sendEvent(t, e = {}) {
            this.emit("beforeSendEvent", t, e);
            let n = function(t, e, n, r) {
                const s = Je(n),
                    o = t.type && "replay_event" !== t.type ? t.type : "event";
                ! function(t, e) {
                    e && (t.sdk = t.sdk || {}, t.sdk.name = t.sdk.name || e.name, t.sdk.version = t.sdk.version || e.version, t.sdk.integrations = [...t.sdk.integrations || [], ...e.integrations || []], t.sdk.packages = [...t.sdk.packages || [], ...e.packages || []])
                }(t, n && n.sdk);
                const i = function(t, e, n, r) {
                    const s = t.sdkProcessingMetadata && t.sdkProcessingMetadata.dynamicSamplingContext;
                    return {
                        event_id: t.event_id,
                        sent_at: (new Date).toISOString(),
                        ...e && {
                            sdk: e
                        },
                        ...!!n && r && {
                            dsn: Le(r)
                        },
                        ...s && {
                            trace: C({ ...s
                            })
                        }
                    }
                }(t, s, r, e);
                return delete t.sdkProcessingMetadata, Ue(i, [
                    [{
                        type: o
                    }, t]
                ])
            }(t, this._dsn, this._options._metadata, this._options.tunnel);
            for (const t of e.attachments || []) n = qe(n, Be(t));
            const r = this.sendEnvelope(n);
            r && r.then((e => this.emit("afterSendEvent", t, e)), null)
        }
        sendSession(t) {
            const e = function(t, e, n, r) {
                const s = Je(n);
                return Ue({
                    sent_at: (new Date).toISOString(),
                    ...s && {
                        sdk: s
                    },
                    ...!!r && e && {
                        dsn: Le(e)
                    }
                }, ["aggregates" in t ? [{
                    type: "sessions"
                }, t] : [{
                    type: "session"
                }, t.toJSON()]])
            }(t, this._dsn, this._options._metadata, this._options.tunnel);
            this.sendEnvelope(e)
        }
        recordDroppedEvent(t, e, n) {
            if (this._options.sendClientReports) {
                const n = `${t}:${e}`;
                B && a.log(`Adding outcome: "${n}"`), this._outcomes[n] = (this._outcomes[n] || 0) + 1
            }
        }
        on(t, e) {
            const n = this._hooks[t] = this._hooks[t] || [];
            return n.push(e), () => {
                const t = n.indexOf(e);
                t > -1 && n.splice(t, 1)
            }
        }
        emit(t, ...e) {
            const n = this._hooks[t];
            n && n.forEach((t => t(...e)))
        }
        sendEnvelope(t) {
            return this.emit("beforeEnvelope", t), this._isEnabled() && this._transport ? this._transport.send(t).then(null, (t => (B && a.error("Error while sending event:", t), t))) : (B && a.error("Transport disabled"), Ft({}))
        }
        _setupIntegrations() {
            const {
                integrations: t
            } = this._options;
            this._integrations = function(t, e) {
                const n = {};
                return e.forEach((e => {
                    e && W(t, e, n)
                })), n
            }(this, t), J(this, t)
        }
        _updateSessionFromEvent(t, e) {
            let n = !1,
                r = !1;
            const s = e.exception && e.exception.values;
            if (s) {
                r = !0;
                for (const t of s) {
                    const e = t.mechanism;
                    if (e && !1 === e.handled) {
                        n = !0;
                        break
                    }
                }
            }
            const o = "ok" === t.status;
            (o && 0 === t.errors || o && n) && (ot(t, { ...n && {
                    status: "crashed"
                },
                errors: t.errors || Number(r || n)
            }), this.captureSession(t))
        }
        _isClientDoneProcessing(t) {
            return new Yt((e => {
                let n = 0;
                const r = setInterval((() => {
                    0 == this._numProcessing ? (clearInterval(r), e(!0)) : (n += 1, t && n >= t && (clearInterval(r), e(!1)))
                }), 1)
            }))
        }
        _isEnabled() {
            return !1 !== this.getOptions().enabled && void 0 !== this._transport
        }
        _prepareEvent(t, e, n, r = yt()) {
            const s = this.getOptions(),
                o = Object.keys(this._integrations);
            return !e.integrations && o.length > 0 && (e.integrations = o), this.emit("preprocessEvent", t, e), t.type || r.setLastEventId(t.event_id || e.event_id), me(s, t, e, n, this, r).then((t => {
                if (null === t) return t;
                const e = { ...r.getPropagationContext(),
                    ...n ? n.getPropagationContext() : void 0
                };
                if ((!t.contexts || !t.contexts.trace) && e) {
                    const {
                        traceId: n,
                        spanId: r,
                        parentSpanId: s,
                        dsc: o
                    } = e;
                    t.contexts = {
                        trace: C({
                            trace_id: n,
                            span_id: r,
                            parent_span_id: s
                        }),
                        ...t.contexts
                    };
                    const i = o || pe(n, this);
                    t.sdkProcessingMetadata = {
                        dynamicSamplingContext: i,
                        ...t.sdkProcessingMetadata
                    }
                }
                return t
            }))
        }
        _captureEvent(t, e = {}, n) {
            return this._processEvent(t, e, n).then((t => t.event_id), (t => {
                if (B) {
                    const e = t;
                    "log" === e.logLevel ? a.log(e.message) : a.warn(e)
                }
            }))
        }
        _processEvent(t, e, n) {
            const r = this.getOptions(),
                {
                    sampleRate: s
                } = r,
                o = tn(t),
                i = Qe(t),
                c = t.type || "error",
                u = `before send for type \`${c}\``,
                l = void 0 === s ? void 0 : function(t) {
                    if ("boolean" == typeof t) return Number(t);
                    const e = "string" == typeof t ? parseFloat(t) : t;
                    if (!("number" != typeof e || isNaN(e) || e < 0 || e > 1)) return e;
                    B && a.warn(`[Tracing] Given sample rate is invalid. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(t)} of type ${JSON.stringify(typeof t)}.`)
                }(s);
            if (i && "number" == typeof l && Math.random() > l) return this.recordDroppedEvent("sample_rate", "error", t), Ht(new We(`Discarding event because it's not included in the random sample (sampling rate = ${s})`, "log"));
            const p = "replay_event" === c ? "replay" : c,
                d = (t.sdkProcessingMetadata || {}).capturedSpanIsolationScope;
            return this._prepareEvent(t, e, n, d).then((n => {
                if (null === n) throw this.recordDroppedEvent("event_processor", p, t), new We("An event processor returned `null`, will not send event.", "log");
                if (e.data && !0 === e.data.__sentry__) return n;
                const s = function(t, e, n, r) {
                    const {
                        beforeSend: s,
                        beforeSendTransaction: o,
                        beforeSendSpan: i
                    } = e;
                    if (Qe(n) && s) return s(n, r);
                    if (tn(n)) {
                        if (n.spans && i) {
                            const e = [];
                            for (const r of n.spans) {
                                const n = i(r);
                                n ? e.push(n) : t.recordDroppedEvent("before_send", "span")
                            }
                            n.spans = e
                        }
                        if (o) return o(n, r)
                    }
                    return n
                }(this, r, n, e);
                return function(t, e) {
                    const n = `${e} must return \`null\` or a valid event.`;
                    if (y(t)) return t.then((t => {
                        if (!_(t) && null !== t) throw new We(n);
                        return t
                    }), (t => {
                        throw new We(`${e} rejected with ${t}`)
                    }));
                    if (!_(t) && null !== t) throw new We(n);
                    return t
                }(s, u)
            })).then((r => {
                if (null === r) {
                    if (this.recordDroppedEvent("before_send", p, t), tn(t)) {
                        const e = 1 + (t.spans || []).length;
                        this._outcomes.span = (this._outcomes.span || 0) + e
                    }
                    throw new We(`${u} returned \`null\`, will not send event.`, "log")
                }
                const s = n && n.getSession();
                !o && s && this._updateSessionFromEvent(s, r);
                const i = r.transaction_info;
                if (o && i && r.transaction !== t.transaction) {
                    const t = "custom";
                    r.transaction_info = { ...i,
                        source: t
                    }
                }
                return this.sendEvent(r, e), r
            })).then(null, (t => {
                if (t instanceof We) throw t;
                throw this.captureException(t, {
                    data: {
                        __sentry__: !0
                    },
                    originalException: t
                }), new We(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.\nReason: ${t}`)
            }))
        }
        _process(t) {
            this._numProcessing++, t.then((t => (this._numProcessing--, t)), (t => (this._numProcessing--, t)))
        }
        _clearOutcomes() {
            const t = this._outcomes;
            return this._outcomes = {}, Object.entries(t).map((([t, e]) => {
                const [n, r] = t.split(":");
                return {
                    reason: n,
                    category: r,
                    quantity: e
                }
            }))
        }
    }

    function Qe(t) {
        return void 0 === t.type
    }

    function tn(t) {
        return "transaction" === t.type
    }
    const en = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__;

    function nn(t, e) {
        const n = sn(t, e),
            r = {
                type: e && e.name,
                value: an(e)
            };
        return n.length && (r.stacktrace = {
            frames: n
        }), void 0 === r.type && "" === r.value && (r.value = "Unrecoverable error caught"), r
    }

    function rn(t, e) {
        return {
            exception: {
                values: [nn(t, e)]
            }
        }
    }

    function sn(t, e) {
        const n = e.stacktrace || e.stack || "",
            r = function(t) {
                return t && on.test(t.message) ? 1 : 0
            }(e),
            s = function(t) {
                return "number" == typeof t.framesToPop ? t.framesToPop : 0
            }(e);
        try {
            return t(n, r, s)
        } catch (t) {}
        return []
    }
    const on = /Minified React error #\d+;/i;

    function an(t) {
        const e = t && t.message;
        return e ? e.error && "string" == typeof e.error.message ? e.error.message : e : "No error message"
    }

    function cn(t, e, n, r, s) {
        let o;
        if (p(e) && e.error) return rn(t, e.error);
        if (d(e) || l(e, "DOMException")) {
            const s = e;
            if ("stack" in e) o = rn(t, e);
            else {
                const e = s.name || (d(s) ? "DOMError" : "DOMException"),
                    i = s.message ? `${e}: ${s.message}` : e;
                o = un(t, i, n, r), q(o, i)
            }
            return "code" in s && (o.tags = { ...o.tags,
                "DOMException.code": `${s.code}`
            }), o
        }
        return u(e) ? rn(t, e) : _(e) || g(e) ? (o = function(t, e, n, r) {
            const s = vt(),
                o = s && s.getOptions().normalizeDepth,
                i = function(t) {
                    for (const e in t)
                        if (Object.prototype.hasOwnProperty.call(t, e)) {
                            const n = t[e];
                            if (n instanceof Error) return n
                        }
                }(e),
                a = {
                    __serialized__: Mt(e, o)
                };
            if (i) return {
                exception: {
                    values: [nn(t, i)]
                },
                extra: a
            };
            const c = {
                exception: {
                    values: [{
                        type: g(e) ? e.constructor.name : r ? "UnhandledRejection" : "Error",
                        value: ln(e, {
                            isUnhandledRejection: r
                        })
                    }]
                },
                extra: a
            };
            if (n) {
                const e = sn(t, n);
                e.length && (c.exception.values[0].stacktrace = {
                    frames: e
                })
            }
            return c
        }(t, e, n, s), F(o, {
            synthetic: !0
        }), o) : (o = un(t, e, n, r), q(o, `${e}`, void 0), F(o, {
            synthetic: !0
        }), o)
    }

    function un(t, e, n, r) {
        const s = {};
        if (r && n) {
            const r = sn(t, n);
            r.length && (s.exception = {
                values: [{
                    value: e,
                    stacktrace: {
                        frames: r
                    }
                }]
            })
        }
        if (h(e)) {
            const {
                __sentry_template_string__: t,
                __sentry_template_values__: n
            } = e;
            return s.logentry = {
                message: t,
                params: n
            }, s
        }
        return s.message = e, s
    }

    function ln(t, {
        isUnhandledRejection: e
    }) {
        const n = function(t, e = 40) {
                const n = Object.keys(P(t));
                n.sort();
                const r = n[0];
                if (!r) return "[object has no keys]";
                if (r.length >= e) return k(r, e);
                for (let t = n.length; t > 0; t--) {
                    const r = n.slice(0, t).join(", ");
                    if (!(r.length > e)) return t === n.length ? r : k(r, e)
                }
                return ""
            }(t),
            r = e ? "promise rejection" : "exception";
        return p(t) ? `Event \`ErrorEvent\` captured as ${r} with message \`${t.message}\`` : g(t) ? `Event \`${function(t){try{const e=Object.getPrototypeOf(t);return e?e.constructor.name:void 0}catch(t){}}(t)}\` (type=${t.type}) captured as ${r}` : `Object captured as ${r} with keys: ${n}`
    }
    const pn = n;
    let dn = 0;

    function fn() {
        return dn > 0
    }

    function hn(t, e = {}, n) {
        if ("function" != typeof t) return t;
        try {
            const e = t.__sentry_wrapped__;
            if (e) return e;
            if (I(t)) return t
        } catch (e) {
            return t
        }
        const r = function() {
            const r = Array.prototype.slice.call(arguments);
            try {
                n && "function" == typeof n && n.apply(this, arguments);
                const s = r.map((t => hn(t, e)));
                return t.apply(this, s)
            } catch (t) {
                throw dn++, setTimeout((() => {
                        dn--
                    })),
                    function(...t) {
                        const e = _t(Z());
                        if (2 === t.length) {
                            const [n, r] = t;
                            return n ? e.withSetScope(n, r) : e.withScope(r)
                        }
                        e.withScope(t[0])
                    }((n => {
                        var s;
                        n.addEventProcessor((t => (e.mechanism && (q(t, void 0, void 0), F(t, e.mechanism)), t.extra = { ...t.extra,
                            arguments: r
                        }, t))), s = t, gt().captureException(s, function(t) {
                            if (t) return function(t) {
                                return t instanceof lt || "function" == typeof t
                            }(t) || function(t) {
                                return Object.keys(t).some((t => ge.includes(t)))
                            }(t) ? {
                                captureContext: t
                            } : t
                        }(undefined))
                    })), t
            }
        };
        try {
            for (const e in t) Object.prototype.hasOwnProperty.call(t, e) && (r[e] = t[e])
        } catch (t) {}
        N(r, t), D(t, "__sentry_wrapped__", r);
        try {
            Object.getOwnPropertyDescriptor(r, "name").configurable && Object.defineProperty(r, "name", {
                get: () => t.name
            })
        } catch (t) {}
        return r
    }
    class mn extends Ze {
        constructor(t) {
            const n = {
                parentSpanIsAlwaysRootSpan: !0,
                ...t
            };
            ! function(t, n, r = [n], s = "npm") {
                const o = t._metadata || {};
                o.sdk || (o.sdk = {
                    name: `sentry.javascript.${n}`,
                    packages: r.map((t => ({
                        name: `${s}:@sentry/${t}`,
                        version: e
                    }))),
                    version: e
                }), t._metadata = o
            }(n, "browser", ["browser"], pn.SENTRY_SDK_SOURCE || "npm"), super(n), n.sendClientReports && pn.document && pn.document.addEventListener("visibilitychange", (() => {
                "hidden" === pn.document.visibilityState && this._flushOutcomes()
            }))
        }
        eventFromException(t, e) {
            return function(t, e, n, r) {
                const s = cn(t, e, n && n.syntheticException || void 0, r);
                return F(s), s.level = "error", n && n.event_id && (s.event_id = n.event_id), Ft(s)
            }(this._options.stackParser, t, e, this._options.attachStacktrace)
        }
        eventFromMessage(t, e = "info", n) {
            return function(t, e, n = "info", r, s) {
                const o = un(t, e, r && r.syntheticException || void 0, s);
                return o.level = n, r && r.event_id && (o.event_id = r.event_id), Ft(o)
            }(this._options.stackParser, t, e, n, this._options.attachStacktrace)
        }
        captureUserFeedback(t) {
            if (!this._isEnabled()) return void(en && a.warn("SDK not enabled, will not capture user feedback."));
            const e = function(t, {
                metadata: e,
                tunnel: n,
                dsn: r
            }) {
                const s = {
                        event_id: t.event_id,
                        sent_at: (new Date).toISOString(),
                        ...e && e.sdk && {
                            sdk: {
                                name: e.sdk.name,
                                version: e.sdk.version
                            }
                        },
                        ...!!n && !!r && {
                            dsn: Le(r)
                        }
                    },
                    o = function(t) {
                        return [{
                            type: "user_report"
                        }, t]
                    }(t);
                return Ue(s, [o])
            }(t, {
                metadata: this.getSdkMetadata(),
                dsn: this.getDsn(),
                tunnel: this.getOptions().tunnel
            });
            this.sendEnvelope(e)
        }
        _prepareEvent(t, e, n) {
            return t.platform = t.platform || "javascript", super._prepareEvent(t, e, n)
        }
        _flushOutcomes() {
            const t = this._clearOutcomes();
            if (0 === t.length) return void(en && a.log("No outcomes to send"));
            if (!this._dsn) return void(en && a.log("No dsn provided, will not send outcomes"));
            en && a.log("Sending outcomes:", t);
            const e = (n = t, Ue((r = this._options.tunnel && Le(this._dsn)) ? {
                dsn: r
            } : {}, [
                [{
                    type: "client_report"
                }, {
                    timestamp: nt(),
                    discarded_events: n
                }]
            ]));
            var n, r;
            this.sendEnvelope(e)
        }
    }
    const _n = 1e3;
    let gn, yn, vn;

    function bn() {
        if (!Pe.document) return;
        const t = Ne.bind(null, "dom"),
            e = En(t, !0);
        Pe.document.addEventListener("click", e, !1), Pe.document.addEventListener("keypress", e, !1), ["EventTarget", "Node"].forEach((e => {
            const n = Pe[e] && Pe[e].prototype;
            n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && ($(n, "addEventListener", (function(e) {
                return function(n, r, s) {
                    if ("click" === n || "keypress" == n) try {
                        const r = this,
                            o = r.__sentry_instrumentation_handlers__ = r.__sentry_instrumentation_handlers__ || {},
                            i = o[n] = o[n] || {
                                refCount: 0
                            };
                        if (!i.handler) {
                            const r = En(t);
                            i.handler = r, e.call(this, n, r, s)
                        }
                        i.refCount++
                    } catch (t) {}
                    return e.call(this, n, r, s)
                }
            })), $(n, "removeEventListener", (function(t) {
                return function(e, n, r) {
                    if ("click" === e || "keypress" == e) try {
                        const n = this,
                            s = n.__sentry_instrumentation_handlers__ || {},
                            o = s[e];
                        o && (o.refCount--, o.refCount <= 0 && (t.call(this, e, o.handler, r), o.handler = void 0, delete s[e]), 0 === Object.keys(s).length && delete n.__sentry_instrumentation_handlers__)
                    } catch (t) {}
                    return t.call(this, e, n, r)
                }
            })))
        }))
    }

    function En(t, e = !1) {
        return n => {
            if (!n || n._sentryCaptured) return;
            const r = function(t) {
                try {
                    return t.target
                } catch (t) {
                    return null
                }
            }(n);
            if (function(t, e) {
                    return "keypress" === t && (!e || !e.tagName || "INPUT" !== e.tagName && "TEXTAREA" !== e.tagName && !e.isContentEditable)
                }(n.type, r)) return;
            D(n, "_sentryCaptured", !0), r && !r._sentryId && D(r, "_sentryId", L());
            const s = "keypress" === n.type ? "input" : n.type;
            (function(t) {
                if (t.type !== yn) return !1;
                try {
                    if (!t.target || t.target._sentryId !== vn) return !1
                } catch (t) {}
                return !0
            })(n) || (t({
                event: n,
                name: s,
                global: e
            }), yn = n.type, vn = r ? r._sentryId : void 0), clearTimeout(gn), gn = Pe.setTimeout((() => {
                vn = void 0, yn = void 0
            }), _n)
        }
    }
    const Sn = "__sentry_xhr_v3__";

    function xn() {
        if (!Pe.XMLHttpRequest) return;
        const t = XMLHttpRequest.prototype;
        $(t, "open", (function(t) {
            return function(...e) {
                const n = 1e3 * rt(),
                    r = f(e[0]) ? e[0].toUpperCase() : void 0,
                    s = function(t) {
                        if (f(t)) return t;
                        try {
                            return t.toString()
                        } catch (t) {}
                    }(e[1]);
                if (!r || !s) return t.apply(this, e);
                this[Sn] = {
                    method: r,
                    url: s,
                    request_headers: {}
                }, "POST" === r && s.match(/sentry_key/) && (this.__sentry_own_request__ = !0);
                const o = () => {
                    const t = this[Sn];
                    if (t && 4 === this.readyState) {
                        try {
                            t.status_code = this.status
                        } catch (t) {}
                        Ne("xhr", {
                            endTimestamp: 1e3 * rt(),
                            startTimestamp: n,
                            xhr: this
                        })
                    }
                };
                return "onreadystatechange" in this && "function" == typeof this.onreadystatechange ? $(this, "onreadystatechange", (function(t) {
                    return function(...e) {
                        return o(), t.apply(this, e)
                    }
                })) : this.addEventListener("readystatechange", o), $(this, "setRequestHeader", (function(t) {
                    return function(...e) {
                        const [n, r] = e, s = this[Sn];
                        return s && f(n) && f(r) && (s.request_headers[n.toLowerCase()] = r), t.apply(this, e)
                    }
                })), t.apply(this, e)
            }
        })), $(t, "send", (function(t) {
            return function(...e) {
                const n = this[Sn];
                return n ? (void 0 !== e[0] && (n.body = e[0]), Ne("xhr", {
                    startTimestamp: 1e3 * rt(),
                    xhr: this
                }), t.apply(this, e)) : t.apply(this, e)
            }
        }))
    }
    const wn = 100;

    function kn(t, e) {
        const n = vt(),
            r = yt();
        if (!n) return;
        const {
            beforeBreadcrumb: s = null,
            maxBreadcrumbs: o = wn
        } = n.getOptions();
        if (o <= 0) return;
        const a = {
                timestamp: nt(),
                ...t
            },
            c = s ? i((() => s(a, e))) : a;
        null !== c && (n.emit && n.emit("beforeAddBreadcrumb", c, e), r.addBreadcrumb(c, o))
    }

    function On() {
        "console" in n && s.forEach((function(t) {
            t in n.console && $(n.console, t, (function(e) {
                return o[t] = e,
                    function(...e) {
                        Ne("console", {
                            args: e,
                            level: t
                        });
                        const r = o[t];
                        r && r.apply(n.console, e)
                    }
            }))
        }))
    }

    function Tn() {
        (function() {
            if ("string" == typeof EdgeRuntime) return !0;
            if (!we()) return !1;
            if (ke(xe.fetch)) return !0;
            let e = !1;
            const n = xe.document;
            if (n && "function" == typeof n.createElement) try {
                const t = n.createElement("iframe");
                t.hidden = !0, n.head.appendChild(t), t.contentWindow && t.contentWindow.fetch && (e = ke(t.contentWindow.fetch)), n.head.removeChild(t)
            } catch (e) {
                t && a.warn("Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ", e)
            }
            return e
        })() && $(n, "fetch", (function(t) {
            return function(...e) {
                const {
                    method: r,
                    url: s
                } = function(t) {
                    if (0 === t.length) return {
                        method: "GET",
                        url: ""
                    };
                    if (2 === t.length) {
                        const [e, n] = t;
                        return {
                            url: Dn(e),
                            method: $n(n, "method") ? String(n.method).toUpperCase() : "GET"
                        }
                    }
                    const e = t[0];
                    return {
                        url: Dn(e),
                        method: $n(e, "method") ? String(e.method).toUpperCase() : "GET"
                    }
                }(e), o = {
                    args: e,
                    fetchData: {
                        method: r,
                        url: s
                    },
                    startTimestamp: 1e3 * rt()
                };
                Ne("fetch", { ...o
                });
                const i = (new Error).stack;
                return t.apply(n, e).then((t => (Ne("fetch", { ...o,
                    endTimestamp: 1e3 * rt(),
                    response: t
                }), t)), (t => {
                    throw Ne("fetch", { ...o,
                        endTimestamp: 1e3 * rt(),
                        error: t
                    }), u(t) && void 0 === t.stack && (t.stack = i, D(t, "framesToPop", 1)), t
                }))
            }
        }))
    }

    function $n(t, e) {
        return !!t && "object" == typeof t && !!t[e]
    }

    function Dn(t) {
        return "string" == typeof t ? t : t ? $n(t, "url") ? t.url : t.toString ? t.toString() : "" : ""
    }
    const Nn = ["fatal", "error", "warning", "log", "info", "debug"];

    function In(t) {
        if (!t) return {};
        const e = t.match(/^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/);
        if (!e) return {};
        const n = e[6] || "",
            r = e[8] || "";
        return {
            host: e[4],
            path: e[5],
            protocol: e[2],
            search: n,
            hash: r,
            relative: e[5] + n + r
        }
    }
    const Pn = (t = {}) => {
            const e = {
                console: !0,
                dom: !0,
                fetch: !0,
                history: !0,
                sentry: !0,
                xhr: !0,
                ...t
            };
            return {
                name: "Breadcrumbs",
                setup(t) {
                    var n;
                    e.console && function(t) {
                        const e = "console";
                        $e(e, t), De(e, On)
                    }(function(t) {
                        return function(e) {
                            if (vt() !== t) return;
                            const n = {
                                category: "console",
                                data: {
                                    arguments: e.args,
                                    logger: "console"
                                },
                                level: (r = e.level, "warn" === r ? "warning" : Nn.includes(r) ? r : "log"),
                                message: O(e.args, " ")
                            };
                            var r;
                            if ("assert" === e.level) {
                                if (!1 !== e.args[0]) return;
                                n.message = `Assertion failed: ${O(e.args.slice(1)," ")||"console.assert"}`, n.data.arguments = e.args.slice(1)
                            }
                            kn(n, {
                                input: e.args,
                                level: e.level
                            })
                        }
                    }(t)), e.dom && (n = function(t, e) {
                        return function(n) {
                            if (vt() !== t) return;
                            let r, s, o = "object" == typeof e ? e.serializeAttribute : void 0,
                                i = "object" == typeof e && "number" == typeof e.maxStringLength ? e.maxStringLength : void 0;
                            i && i > 1024 && (en && a.warn(`\`dom.maxStringLength\` cannot exceed 1024, but a value of ${i} was configured. Sentry will use 1024 instead.`), i = 1024), "string" == typeof o && (o = [o]);
                            try {
                                const t = n.event,
                                    e = function(t) {
                                        return !!t && !!t.target
                                    }(t) ? t.target : t;
                                r = x(e, {
                                    keyAttrs: o,
                                    maxStringLength: i
                                }), s = function(t) {
                                    if (!E.HTMLElement) return null;
                                    let e = t;
                                    for (let t = 0; t < 5; t++) {
                                        if (!e) return null;
                                        if (e instanceof HTMLElement) {
                                            if (e.dataset.sentryComponent) return e.dataset.sentryComponent;
                                            if (e.dataset.sentryElement) return e.dataset.sentryElement
                                        }
                                        e = e.parentNode
                                    }
                                    return null
                                }(e)
                            } catch (t) {
                                r = "<unknown>"
                            }
                            if (0 === r.length) return;
                            const c = {
                                category: `ui.${n.name}`,
                                message: r
                            };
                            s && (c.data = {
                                "ui.component_name": s
                            }), kn(c, {
                                event: n.event,
                                name: n.name,
                                global: n.global
                            })
                        }
                    }(t, e.dom), $e("dom", n), De("dom", bn)), e.xhr && function(t) {
                        $e("xhr", t), De("xhr", xn)
                    }(function(t) {
                        return function(e) {
                            if (vt() !== t) return;
                            const {
                                startTimestamp: n,
                                endTimestamp: r
                            } = e, s = e.xhr[Sn];
                            if (!n || !r || !s) return;
                            const {
                                method: o,
                                url: i,
                                status_code: a,
                                body: c
                            } = s;
                            kn({
                                category: "xhr",
                                data: {
                                    method: o,
                                    url: i,
                                    status_code: a
                                },
                                type: "http"
                            }, {
                                xhr: e.xhr,
                                input: c,
                                startTimestamp: n,
                                endTimestamp: r
                            })
                        }
                    }(t)), e.fetch && function(t) {
                        const e = "fetch";
                        $e(e, t), De(e, Tn)
                    }(function(t) {
                        return function(e) {
                            if (vt() !== t) return;
                            const {
                                startTimestamp: n,
                                endTimestamp: r
                            } = e;
                            if (r && (!e.fetchData.url.match(/sentry_key/) || "POST" !== e.fetchData.method))
                                if (e.error) kn({
                                    category: "fetch",
                                    data: e.fetchData,
                                    level: "error",
                                    type: "http"
                                }, {
                                    data: e.error,
                                    input: e.args,
                                    startTimestamp: n,
                                    endTimestamp: r
                                });
                                else {
                                    const t = e.response;
                                    kn({
                                        category: "fetch",
                                        data: { ...e.fetchData,
                                            status_code: t && t.status
                                        },
                                        type: "http"
                                    }, {
                                        input: e.args,
                                        response: t,
                                        startTimestamp: n,
                                        endTimestamp: r
                                    })
                                }
                        }
                    }(t)), e.history && Re(function(t) {
                        return function(e) {
                            if (vt() !== t) return;
                            let n = e.from,
                                r = e.to;
                            const s = In(pn.location.href);
                            let o = n ? In(n) : void 0;
                            const i = In(r);
                            o && o.path || (o = s), s.protocol === i.protocol && s.host === i.host && (r = i.relative), s.protocol === o.protocol && s.host === o.host && (n = o.relative), kn({
                                category: "navigation",
                                data: {
                                    from: n,
                                    to: r
                                }
                            })
                        }
                    }(t)), e.sentry && t.on("beforeSendEvent", function(t) {
                        return function(e) {
                            vt() === t && kn({
                                category: "sentry." + ("transaction" === e.type ? "transaction" : "event"),
                                event_id: e.event_id,
                                level: e.level,
                                message: U(e)
                            }, {
                                event: e
                            })
                        }
                    }(t))
                }
            }
        },
        jn = ["EventTarget", "Window", "Node", "ApplicationCache", "AudioTrackList", "BroadcastChannel", "ChannelMergerNode", "CryptoOperation", "EventSource", "FileReader", "HTMLUnknownElement", "IDBDatabase", "IDBRequest", "IDBTransaction", "KeyOperation", "MediaController", "MessagePort", "ModalWindow", "Notification", "SVGElementInstance", "Screen", "SharedWorker", "TextTrack", "TextTrackCue", "TextTrackList", "WebSocket", "WebSocketWorker", "Worker", "XMLHttpRequest", "XMLHttpRequestEventTarget", "XMLHttpRequestUpload"],
        Rn = (t = {}) => {
            const e = {
                XMLHttpRequest: !0,
                eventTarget: !0,
                requestAnimationFrame: !0,
                setInterval: !0,
                setTimeout: !0,
                ...t
            };
            return {
                name: "BrowserApiErrors",
                setupOnce() {
                    e.setTimeout && $(pn, "setTimeout", Cn), e.setInterval && $(pn, "setInterval", Cn), e.requestAnimationFrame && $(pn, "requestAnimationFrame", An), e.XMLHttpRequest && "XMLHttpRequest" in pn && $(XMLHttpRequest.prototype, "send", Ln);
                    const t = e.eventTarget;
                    t && (Array.isArray(t) ? t : jn).forEach(Mn)
                }
            }
        };

    function Cn(t) {
        return function(...e) {
            const n = e[0];
            return e[0] = hn(n, {
                mechanism: {
                    data: {
                        function: Nt(t)
                    },
                    handled: !1,
                    type: "instrument"
                }
            }), t.apply(this, e)
        }
    }

    function An(t) {
        return function(e) {
            return t.apply(this, [hn(e, {
                mechanism: {
                    data: {
                        function: "requestAnimationFrame",
                        handler: Nt(t)
                    },
                    handled: !1,
                    type: "instrument"
                }
            })])
        }
    }

    function Ln(t) {
        return function(...e) {
            const n = this;
            return ["onload", "onerror", "onprogress", "onreadystatechange"].forEach((t => {
                t in n && "function" == typeof n[t] && $(n, t, (function(e) {
                    const n = {
                            mechanism: {
                                data: {
                                    function: t,
                                    handler: Nt(e)
                                },
                                handled: !1,
                                type: "instrument"
                            }
                        },
                        r = I(e);
                    return r && (n.mechanism.data.handler = Nt(r)), hn(e, n)
                }))
            })), t.apply(this, e)
        }
    }

    function Mn(t) {
        const e = pn,
            n = e[t] && e[t].prototype;
        n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && ($(n, "addEventListener", (function(e) {
            return function(n, r, s) {
                try {
                    "function" == typeof r.handleEvent && (r.handleEvent = hn(r.handleEvent, {
                        mechanism: {
                            data: {
                                function: "handleEvent",
                                handler: Nt(r),
                                target: t
                            },
                            handled: !1,
                            type: "instrument"
                        }
                    }))
                } catch (t) {}
                return e.apply(this, [n, hn(r, {
                    mechanism: {
                        data: {
                            function: "addEventListener",
                            handler: Nt(r),
                            target: t
                        },
                        handled: !1,
                        type: "instrument"
                    }
                }), s])
            }
        })), $(n, "removeEventListener", (function(t) {
            return function(e, n, r) {
                const s = n;
                try {
                    const n = s && s.__sentry_wrapped__;
                    n && t.call(this, e, n, r)
                } catch (t) {}
                return t.call(this, e, s, r)
            }
        })))
    }
    let Un = null;

    function qn() {
        Un = n.onerror, n.onerror = function(t, e, n, r, s) {
            return Ne("error", {
                column: r,
                error: s,
                line: n,
                msg: t,
                url: e
            }), !(!Un || Un.__SENTRY_LOADER__) && Un.apply(this, arguments)
        }, n.onerror.__SENTRY_INSTRUMENTED__ = !0
    }
    let Fn = null;

    function Hn() {
        Fn = n.onunhandledrejection, n.onunhandledrejection = function(t) {
            return Ne("unhandledrejection", t), !(Fn && !Fn.__SENTRY_LOADER__) || Fn.apply(this, arguments)
        }, n.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0
    }
    const Yn = (t = {}) => {
        const e = {
            onerror: !0,
            onunhandledrejection: !0,
            ...t
        };
        return {
            name: "GlobalHandlers",
            setupOnce() {
                Error.stackTraceLimit = 50
            },
            setup(t) {
                e.onerror && (function(t) {
                    ! function(e) {
                        const n = "error";
                        $e(n, (e => {
                            const {
                                stackParser: n,
                                attachStacktrace: r
                            } = Gn();
                            if (vt() !== t || fn()) return;
                            const {
                                msg: s,
                                url: o,
                                line: i,
                                column: a,
                                error: c
                            } = e, u = function(t, e, n, r) {
                                const s = t.exception = t.exception || {},
                                    o = s.values = s.values || [],
                                    i = o[0] = o[0] || {},
                                    a = i.stacktrace = i.stacktrace || {},
                                    c = a.frames = a.frames || [],
                                    u = isNaN(parseInt(r, 10)) ? void 0 : r,
                                    l = isNaN(parseInt(n, 10)) ? void 0 : n,
                                    p = f(e) && e.length > 0 ? e : function() {
                                        try {
                                            return E.document.location.href
                                        } catch (t) {
                                            return ""
                                        }
                                    }();
                                return 0 === c.length && c.push({
                                    colno: u,
                                    filename: p,
                                    function: wt,
                                    in_app: !0,
                                    lineno: l
                                }), t
                            }(cn(n, c || s, void 0, r, !1), o, i, a);
                            u.level = "error", ye(u, {
                                originalException: c,
                                mechanism: {
                                    handled: !1,
                                    type: "onerror"
                                }
                            })
                        })), De(n, qn)
                    }()
                }(t), Bn("onerror")), e.onunhandledrejection && (function(t) {
                    ! function(e) {
                        const n = "unhandledrejection";
                        $e(n, (e => {
                            const {
                                stackParser: n,
                                attachStacktrace: r
                            } = Gn();
                            if (vt() !== t || fn()) return;
                            const s = function(t) {
                                    if (m(t)) return t;
                                    try {
                                        if ("reason" in t) return t.reason;
                                        if ("detail" in t && "reason" in t.detail) return t.detail.reason
                                    } catch (t) {}
                                    return t
                                }(e),
                                o = m(s) ? {
                                    exception: {
                                        values: [{
                                            type: "UnhandledRejection",
                                            value: `Non-Error promise rejection captured with value: ${String(s)}`
                                        }]
                                    }
                                } : cn(n, s, void 0, r, !0);
                            o.level = "error", ye(o, {
                                originalException: s,
                                mechanism: {
                                    handled: !1,
                                    type: "onunhandledrejection"
                                }
                            })
                        })), De(n, Hn)
                    }()
                }(t), Bn("onunhandledrejection"))
            }
        }
    };

    function Bn(t) {
        en && a.log(`Global Handler attached: ${t}`)
    }

    function Gn() {
        const t = vt();
        return t && t.getOptions() || {
            stackParser: () => [],
            attachStacktrace: !1
        }
    }

    function zn(t, e, n = 250, r, s, o, i) {
        if (!(o.exception && o.exception.values && i && v(i.originalException, Error))) return;
        const a = o.exception.values.length > 0 ? o.exception.values[o.exception.values.length - 1] : void 0;
        var c, u;
        a && (o.exception.values = (c = Jn(t, e, s, i.originalException, r, o.exception.values, a, 0), u = n, c.map((t => (t.value && (t.value = k(t.value, u)), t)))))
    }

    function Jn(t, e, n, r, s, o, i, a) {
        if (o.length >= n + 1) return o;
        let c = [...o];
        if (v(r[s], Error)) {
            Wn(i, a);
            const o = t(e, r[s]),
                u = c.length;
            Vn(o, s, u, a), c = Jn(t, e, n, r[s], s, [o, ...c], o, u)
        }
        return Array.isArray(r.errors) && r.errors.forEach(((r, o) => {
            if (v(r, Error)) {
                Wn(i, a);
                const u = t(e, r),
                    l = c.length;
                Vn(u, `errors[${o}]`, l, a), c = Jn(t, e, n, r, s, [u, ...c], u, l)
            }
        })), c
    }

    function Wn(t, e) {
        t.mechanism = t.mechanism || {
            type: "generic",
            handled: !0
        }, t.mechanism = { ...t.mechanism,
            ..."AggregateError" === t.type && {
                is_exception_group: !0
            },
            exception_id: e
        }
    }

    function Vn(t, e, n, r) {
        t.mechanism = t.mechanism || {
            type: "generic",
            handled: !0
        }, t.mechanism = { ...t.mechanism,
            type: "chained",
            source: e,
            exception_id: n,
            parent_id: r
        }
    }
    const Kn = (t = {}) => {
        const e = t.limit || 5,
            n = t.key || "cause";
        return {
            name: "LinkedErrors",
            preprocessEvent(t, r, s) {
                const o = s.getOptions();
                zn(nn, o.stackParser, o.maxValueLength, n, e, t, r)
            }
        }
    };

    function Xn(t, e, n, r) {
        const s = {
            filename: t,
            function: "<anonymous>" === e ? wt : e,
            in_app: !0
        };
        return void 0 !== n && (s.lineno = n), void 0 !== r && (s.colno = r), s
    }
    const Zn = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
        Qn = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
        tr = /\((\S*)(?::(\d+))(?::(\d+))\)/,
        er = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
        nr = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
        rr = Tt([30, t => {
            const e = Zn.exec(t);
            if (e) {
                const [, t, n, r] = e;
                return Xn(t, wt, +n, +r)
            }
            const n = Qn.exec(t);
            if (n) {
                if (n[2] && 0 === n[2].indexOf("eval")) {
                    const t = tr.exec(n[2]);
                    t && (n[2] = t[1], n[3] = t[2], n[4] = t[3])
                }
                const [t, e] = sr(n[1] || wt, n[2]);
                return Xn(e, t, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0)
            }
        }], [50, t => {
            const e = er.exec(t);
            if (e) {
                if (e[3] && e[3].indexOf(" > eval") > -1) {
                    const t = nr.exec(e[3]);
                    t && (e[1] = e[1] || "eval", e[3] = t[1], e[4] = t[2], e[5] = "")
                }
                let t = e[3],
                    n = e[1] || wt;
                return [n, t] = sr(n, t), Xn(t, n, e[4] ? +e[4] : void 0, e[5] ? +e[5] : void 0)
            }
        }]),
        sr = (t, e) => {
            const n = -1 !== t.indexOf("safari-extension"),
                r = -1 !== t.indexOf("safari-web-extension");
            return n || r ? [-1 !== t.indexOf("@") ? t.split("@")[0] : wt, n ? `safari-extension:${e}` : `safari-web-extension:${e}`] : [t, e]
        },
        or = "undefined" == typeof __SENTRY_DEBUG__ || __SENTRY_DEBUG__,
        ir = {};

    function ar(t) {
        ir[t] = void 0
    }
    const cr = 6e4;
    const ur = 64;

    function lr(t, e, n = function(t) {
        const e = [];

        function n(t) {
            return e.splice(e.indexOf(t), 1)[0] || Promise.resolve(void 0)
        }
        return {
            $: e,
            add: function(r) {
                if (!(void 0 === t || e.length < t)) return Ht(new We("Not adding Promise because buffer limit was reached."));
                const s = r();
                return -1 === e.indexOf(s) && e.push(s), s.then((() => n(s))).then(null, (() => n(s).then(null, (() => {})))), s
            },
            drain: function(t) {
                return new Yt(((n, r) => {
                    let s = e.length;
                    if (!s) return n(!0);
                    const o = setTimeout((() => {
                        t && t > 0 && n(!1)
                    }), t);
                    e.forEach((t => {
                        Ft(t).then((() => {
                            --s || (clearTimeout(o), n(!0))
                        }), r)
                    }))
                }))
            }
        }
    }(t.bufferSize || ur)) {
        let r = {};
        return {
            send: function(s) {
                const o = [];
                if (Fe(s, ((e, n) => {
                        const s = ze(n);
                        if (function(t, e, n = Date.now()) {
                                return function(t, e) {
                                    return t[e] || t.all || 0
                                }(t, e) > n
                            }(r, s)) {
                            const r = pr(e, n);
                            t.recordDroppedEvent("ratelimit_backoff", s, r)
                        } else o.push(e)
                    })), 0 === o.length) return Ft({});
                const i = Ue(s[0], o),
                    c = e => {
                        Fe(i, ((n, r) => {
                            const s = pr(n, r);
                            t.recordDroppedEvent(e, ze(r), s)
                        }))
                    };
                return n.add((() => e({
                    body: Ye(i)
                }).then((t => (void 0 !== t.statusCode && (t.statusCode < 200 || t.statusCode >= 300) && B && a.warn(`Sentry responded with status code ${t.statusCode} to sent event.`), r = function(t, {
                    statusCode: e,
                    headers: n
                }, r = Date.now()) {
                    const s = { ...t
                        },
                        o = n && n["x-sentry-rate-limits"],
                        i = n && n["retry-after"];
                    if (o)
                        for (const t of o.trim().split(",")) {
                            const [e, n, , , o] = t.split(":", 5), i = parseInt(e, 10), a = 1e3 * (isNaN(i) ? 60 : i);
                            if (n)
                                for (const t of n.split(";")) "metric_bucket" === t && o && !o.split(";").includes("custom") || (s[t] = r + a);
                            else s.all = r + a
                        } else i ? s.all = r + function(t, e = Date.now()) {
                            const n = parseInt(`${t}`, 10);
                            if (!isNaN(n)) return 1e3 * n;
                            const r = Date.parse(`${t}`);
                            return isNaN(r) ? cr : r - e
                        }(i, r) : 429 === e && (s.all = r + 6e4);
                    return s
                }(r, t), t)), (t => {
                    throw c("network_error"), t
                })))).then((t => t), (t => {
                    if (t instanceof We) return B && a.error("Skipped sending event because buffer is full."), c("queue_overflow"), Ft({});
                    throw t
                }))
            },
            flush: t => n.drain(t)
        }
    }

    function pr(t, e) {
        if ("event" === e || "transaction" === e) return Array.isArray(t) ? t[1] : void 0
    }

    function dr(t, e = function(t) {
        const e = ir[t];
        if (e) return e;
        let n = Pe[t];
        if (ke(n)) return ir[t] = n.bind(Pe);
        const r = Pe.document;
        if (r && "function" == typeof r.createElement) try {
            const e = r.createElement("iframe");
            e.hidden = !0, r.head.appendChild(e);
            const s = e.contentWindow;
            s && s[t] && (n = s[t]), r.head.removeChild(e)
        } catch (e) {
            or && a.warn(`Could not create sandbox iframe for ${t} check, bailing to window.${t}: `, e)
        }
        return n ? ir[t] = n.bind(Pe) : n
    }("fetch")) {
        let n = 0,
            r = 0;
        return lr(t, (function(s) {
            const o = s.body.length;
            n += o, r++;
            const i = {
                body: s.body,
                method: "POST",
                referrerPolicy: "origin",
                headers: t.headers,
                keepalive: n <= 6e4 && r < 15,
                ...t.fetchOptions
            };
            if (!e) return ar("fetch"), Ht("No fetch implementation available");
            try {
                return e(t.url, i).then((t => (n -= o, r--, {
                    statusCode: t.status,
                    headers: {
                        "x-sentry-rate-limits": t.headers.get("X-Sentry-Rate-Limits"),
                        "retry-after": t.headers.get("Retry-After")
                    }
                })))
            } catch (t) {
                return ar("fetch"), n -= o, r--, Ht(t)
            }
        }))
    }
    var fr = function() {
            return fr = Object.assign || function(t) {
                for (var e, n = 1, r = arguments.length; n < r; n++)
                    for (var s in e = arguments[n]) Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
                return t
            }, fr.apply(this, arguments)
        },
        hr = "scripts.id",
        mr = [{
            pathRegexp: /https:\/\/[a-zA-Z0-9.-]+\/forms\/main\.js/,
            id: "inShopForms",
            ignoredErrors: ["TypeError: Load failed"]
        }, {
            pathRegexp: /https:\/\/[a-zA-Z0-9.-]+\/forms\/landingPage\.js/,
            id: "landingPage"
        }];
    ! function(t = {}) {
        const e = function(t = {}) {
            return {
                defaultIntegrations: [K(), St(), Rn(), Pn(), Yn(), Kn(), Pt(), {
                    name: "HttpContext",
                    preprocessEvent(t) {
                        if (!pn.navigator && !pn.location && !pn.document) return;
                        const e = t.request && t.request.url || pn.location && pn.location.href,
                            {
                                referrer: n
                            } = pn.document || {},
                            {
                                userAgent: r
                            } = pn.navigator || {},
                            s = { ...t.request && t.request.headers,
                                ...n && {
                                    Referer: n
                                },
                                ...r && {
                                    "User-Agent": r
                                }
                            },
                            o = { ...t.request,
                                ...e && {
                                    url: e
                                },
                                headers: s
                            };
                        t.request = o
                    }
                }],
                release: "string" == typeof __SENTRY_RELEASE__ ? __SENTRY_RELEASE__ : pn.SENTRY_RELEASE && pn.SENTRY_RELEASE.id ? pn.SENTRY_RELEASE.id : void 0,
                autoSessionTracking: !0,
                sendClientReports: !0,
                ...t
            }
        }(t);
        if (function() {
                const t = pn,
                    e = t[t.chrome ? "chrome" : "browser"],
                    n = e && e.runtime && e.runtime.id,
                    r = pn.location && pn.location.href || "",
                    s = !!n && pn === pn.top && ["chrome-extension:", "moz-extension:", "ms-browser-extension:"].some((t => r.startsWith(`${t}//`))),
                    o = void 0 !== t.nw;
                return !!n && !s && !o
            }()) return void i((() => {
            console.error("[Sentry] You cannot run Sentry this way in a browser extension, check: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/")
        }));
        en && (we() || a.warn("No Fetch API detected. The Sentry SDK requires a Fetch API compatible environment to send events. Please add a Fetch API polyfill."));
        const n = { ...e,
            stackParser: (r = e.stackParser || rr, Array.isArray(r) ? Tt(...r) : r),
            integrations: z(e),
            transport: e.transport || dr
        };
        var r;
        const s = function(t, e) {
            !0 === e.debug && (B ? a.enable() : i((() => {
                console.warn("[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle.")
            }))), gt().update(e.initialScope);
            const n = new t(e);
            return function(t) {
                gt().setClient(t)
            }(n), n.init(), n
        }(mn, n);
        e.autoSessionTracking && (void 0 !== pn.document ? (ve({
            ignoreDuration: !0
        }), Se(), Re((({
            from: t,
            to: e
        }) => {
            void 0 !== t && t !== e && (ve({
                ignoreDuration: !0
            }), Se())
        }))) : en && a.warn("Session tracking in non-browser environment with @sentry/browser is not supported."))
    }({
        dsn: "https://fb28959843fa0e5b4e2bd4b953771f78@o511301.ingest.us.sentry.io/4507655113801728",
        environment: "production",
        enabled: !0,
        integrations: [Rn({
            setTimeout: !0,
            setInterval: !0,
            requestAnimationFrame: !0,
            XMLHttpRequest: !0,
            eventTarget: !1
        })],
        tracesSampleRate: 0,
        allowUrls: mr.map((function(t) {
            return t.pathRegexp
        })),
        beforeSend: function(t) {
            var e, n, r, s, o, i, a, c, u = (null === (n = null === (e = null == t ? void 0 : t.exception) || void 0 === e ? void 0 : e.values) || void 0 === n ? void 0 : n.length) && (null === (r = t.exception.values[0]) || void 0 === r ? void 0 : r.stacktrace),
                l = (null === (o = null === (s = null == t ? void 0 : t.exception) || void 0 === s ? void 0 : s.values) || void 0 === o ? void 0 : o.length) && (null === (i = t.exception.values[0]) || void 0 === i ? void 0 : i.value) || "";
            return u && (null === (a = null == u ? void 0 : u.frames) || void 0 === a ? void 0 : a.length) ? (mr.forEach((function(e) {
                var n = e.pathRegexp,
                    r = e.id,
                    s = e.ignoredErrors,
                    o = u.frames.some((function(t) {
                        return n.test(t.filename)
                    })),
                    i = null == s ? void 0 : s.some((function(t) {
                        return l.includes(t)
                    }));
                o && !i && (t = function(t, e) {
                    return t.tags = t.tags || {}, t.tags[hr] = e, t
                }(t, r))
            })), (null === (c = t.tags) || void 0 === c ? void 0 : c[hr]) ? t = function(t) {
                return t.extra = fr(fr({}, t.extra), {
                    full_event: JSON.stringify(t, null, 4)
                }), t
            }(t) : null) : null
        }
    })
}();
//# sourceMappingURL=monitoring.js.map