// All rights reserved by Omnisend Ltd. Look, but don't touch.
// https://www.omnisend.com/
// v4.0.1
if ("undefined" == typeof window.OMNISEND_EMBED_SHOPIFY_LOADED) {
    window.OMNISEND_EMBED_SHOPIFY_LOADED = !0;
    try {
        window._omnisend = function(n) {
                "use strict";
                return n.config = {
                    snippetVersion: "4.0.1",
                    snippetHost: "https://omnisnippet1.com/",
                    appHost: "https://app.omnisend.com/",
                    pickerAPIHost: "https://app.omnisend.com/",
                    customEventsHost: "https://api.omnisend.com/",
                    wtAPIHost: "https://wt.omnisendlink.com/",
                    pnHost: "https://pn.soundestlink.com/",
                    allowedOrigins: ["https://app.omnisend.com"]
                }, n
            }(window._omnisend || {}), window._omnisend = window._omnisend || {}, _omnisend.shopType = "shopify", _omnisend.version = (new Date).toISOString().slice(0, 13),
            function() {
                "use strict";
                var n = document.createElement("script");
                n.type = "text/javascript", n.async = !0, n.src = window._omnisend.config.snippetHost + "inshop/launcher-v2.js?v=" + _omnisend.version;
                var t = document.getElementsByTagName("script")[0];
                t.parentNode.insertBefore(n, t)
            }()
    } catch (ignore) {}
}